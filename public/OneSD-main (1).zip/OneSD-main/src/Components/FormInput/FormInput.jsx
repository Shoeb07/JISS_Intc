import React from "react";
import "./FormInput.css";

const FormInput = ({ field, readOnly, value, onChange }) => {
  return (
    <div className="flex flex-col m-2">
      <label className="text-white" htmlFor={field?.name}>
        {field?.label}
      </label>
      <input
        name={field?.name}
        type={field?.type}
        readOnly={readOnly}
        className=" inputField border-2 border-black outline-none rounded-md"
        value={value}
        onChange={onChange}
        placeholder={field.placeholder}
      />
    </div>
  );
};

export default FormInput;
