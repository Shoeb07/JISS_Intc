import axios from "axios";
import React, { useEffect, useState } from "react";
import { FaHome } from "react-icons/fa";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { MdAddCircleOutline } from "react-icons/md";
import { useNavigate } from "react-router-dom";

const DgProposals = () => {
  const Navigate = useNavigate();
  const [proposals, setProposals] = useState();

  useEffect(() => {
    const getProposals = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllProposals"
        );
        const data = response.data.data;

        setProposals(data);
        console.log(data, 'pro')
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getProposals();
  }, []);

  return (
    <div className="DgCompanys-main">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div className="flex-1 text-center cursor-pointer uppercase  text-2xl"></div>
        <div className="flex-1 flex justify-end items-center  gap-5">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("/dglory/clients/registration")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem]" />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="cards" onClick={() => Navigate("/dglory/po")}>
        <div className="outer flex gap-2 items-center">
          <h2 className="text-xl font-semibold text-white">Proposals </h2>
          <MdAddCircleOutline className="text-xl text-white" />
        </div>
      </div>

      <div className="p-8 w-full h-full">
        <div className="existingCompanies p-4">
          <h2 className="text-xl text-center p-3 uppercase tracking-wider">
            Proposals
          </h2>
          <div className="grid grid-cols-5 gap-4 font-bold text-white bg-gray-800 p-2 rounded">
            <div>Unique ID</div>
            <div>Project Title</div>
            <div>Client Name</div>
            <div>Project Manager </div>
            <div>Total Project Value</div>
          </div>
          {proposals?.map((values, id) => (
            <div
              key={id}
              className="grid grid-cols-5 gap-4 p-2 border-b border-gray-200"
            >
              <div>{values?.uniq_id}</div>
              <div>{values?.Project_title}</div>
              <div>{values?.Client_name}</div>
              <div>{values?.Project_Manager}</div>
              <div>{values?.Total}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DgProposals;
