import React, { useState } from "react";
import "./cRegs.css";
import { Form, Formik } from "formik";
import FormikField from "../../Components/Formik/FormikField";
import * as Yup from "yup";
import axios from "axios";
import { toast } from "react-toastify";
import { MdOutlineKeyboardBackspace } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";

const Registration = () => {
  // const URL = process.env.REACT_APP_1SD_API_URL
  const Navigate =  useNavigate();
  const [registrationInput, setRegistrationInput] = useState({});

  const formSchema = Yup.object().shape({
    // CRName_EN: Yup.string().required('Client Name Is Required'),
    ShortName_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    CRName_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    UnifiedNo_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    CRNo_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // IssueDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // ExpiryDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    VATNo_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // VATIssueDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // VATExpiryDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    OwnerName_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    OwnerDOB_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    OwnerID_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // OwnerIDIssueDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // OwnerIDExpiryDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    AccountName_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    AccountNo_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    IBANNo_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    SwiftCode_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    BranchName_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    CityName_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    ContactPerson_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    MobileNo1_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    LandlineNo_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    POBox_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    ZipCode_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),

  });

  const initialValues = {
    ShortName_EN: "",
    ShortName_AR: "",
    CRName_EN: "",
    CRName_AR: "",
    CRNo_EN: "",
    CRNo_AR: "",
    UnifiedNo_EN: "",
    UnifiedNo_AR: "",
    IssueDate_EN: "",
    IssueDate_AR: "",
    ExpiryDate_EN: "",
    ExpiryDate_AR: "",
    VATNo_EN: "",
    VATNo_AR: "",
    VATIssueDate_EN: "",
    VATIssueDate_AR: "",
    VATExpiryDate_EN: "",
    VATExpiryDate_AR: "",
    OwnerName_EN: "",
    OwnerName_AR: "",
    OwnerDOB_EN: "",
    OwnerDOB_AR: "",
    OwnerID_EN: "",
    OwnerID_AR: "",
    OwnerIDIssueDate_EN: "",
    OwnerIDIssueDate_AR: "",
    OwnerIDExpiryDate_EN: "",
    OwnerIDExpiryDate_AR: "",
    AccountName_EN: "",
    AccountName_AR: "",
    AccountNo_EN: "",
    AccountNo_AR: "",
    IBANNo_EN: "",
    IBANNo_AR: "",
    SwiftCode_EN: "",
    SwiftCode_AR: "",
    BranchName_EN: "",
    BranchName_AR: "",
    CityName_EN: "",
    CityName_AR: "",
    CountryName_EN: "",
    CountryName_AR: "",
    CurrencyName_EN: "", // Set to an empty string by default or any specific currency code
    ContactPerson_EN: "",
    ContactPerson_AR: "",
    Email1: "",
    Email2: "",
    MobileNo1_EN: "",
    MobileNo1_AR: "",
    MobileNo2_EN: "",
    LandlineNo_EN: "",
    LandlineNo_AR: "",
    POBox_EN: "",
    POBox_AR: "",
    ZipCode_EN: "",
    ZipCode_AR: "",
  };

  const RegistrationFields = [
    {
      heading: "Client Registration",
      fields: [
        {
          name: "ShortName_EN",
          label: "Short Name EN",
          placeholder: "Short Name EN",
          type: "text",
        },
        {
          name: "ShortName_AR",
          label: "Short Name AR",
          placeholder: "Short Name AR",
          type: "text",
        },
        {
          name: "CRName_EN",
          label: "CR Name EN",
          placeholder: "CR Name EN",
          type: "text",
        },
        {
          name: "CRName_AR",
          label: "CR Name AR",
          placeholder: "CR Name AR",
          type: "text",
        },
        {
          name: "CRNo_EN",
          label: "CR Number EN",
          placeholder: "CR Number EN",
          type: "text",
        },
        {
          name: "CRNo_AR",
          label: "CR Number AR",
          placeholder: "CR Number AR",
          type: "text",
        },
        {
          name: "UnifiedNo_EN",
          label: "Unified Number EN",
          placeholder: "Unified Number EN",
          type: "text",
        },
        {
          name: "UnifiedNo_AR",
          label: "Unified Number AR",
          placeholder: "Unified Number AR",
          type: "text",
        },
        {
          name: "IssueDate_EN",
          label: "Issue Date EN",
          placeholder: "Issue Date EN",
          type: "date",
        },
        {
          name: "IssueDate_AR",
          label: "Issue Date AR",
          placeholder: "Issue Date AR",
          type: "date",
        },
        {
          name: "ExpiryDate_EN",
          label: "Expiry Date EN",
          placeholder: "Expiry Date EN",
          type: "date",
        },
        {
          name: "ExpiryDate_AR",
          label: "Expiry Date AR",
          placeholder: "Expiry Date AR",
          type: "date",
        },
      ],
    },
    {
      heading: "VAT Details",
      fields: [
        {
          name: "VATNo_EN",
          label: "VAT No EN",
          placeholder: "VAT No EN",
          type: "text",
        },
        {
          name: "VATNo_AR",
          label: "VAT No AR",
          placeholder: "VAT No AR",
          type: "text",
        },
        {
          name: "VATIssueDate_EN",
          label: "VAT Issue Date EN",
          placeholder: "VAT Issue Date EN",
          type: "date",
        },
        {
          name: "VATIssueDate_AR",
          label: "VAT Issue Date AR",
          placeholder: "VAT Issue Date AR",
          type: "date",
        },
        {
          name: "VATExpiryDate_EN",
          label: "VAT Expiry Date EN",
          placeholder: "VAT Expiry Date EN",
          type: "date",
        },
        {
          name: "VATExpiryDate_AR",
          label: "VAT Expiry Date AR",
          placeholder: "VAT Expiry Date AR",
          type: "date",
        },
      ],
    },
    {
      heading: "Owner Details",
      fields: [
        {
          name: "OwnerName_EN",
          label: "Owners Name EN",
          placeholder: "Owners Name EN",
          type: "text",
        },
        {
          name: "OwnerName_AR",
          label: "Owners Name AR",
          placeholder: "Owners Name AR",
          type: "text",
        },
        {
          name: "OwnerDOB_EN",
          label: "Owners DOB EN",
          placeholder: "Owners DOB EN",
          type: "text",
        },
        {
          name: "OwnerDOB_AR",
          label: "Owners DOB AR",
          placeholder: "Owners DOB AR",
          type: "text",
        },
        {
          name: "OwnerID_EN",
          label: "Owners ID EN",
          placeholder: "Owners ID EN",
          type: "text",
        },
        {
          name: "OwnerID_AR",
          label: "Owners ID AR",
          placeholder: "Owners ID AR",
          type: "text",
        },
        {
          name: "OwnerIDIssueDate_EN",
          label: "Owners ID Issue Date EN",
          placeholder: "Owners ID Issue Date EN",
          type: "date",
        },
        {
          name: "OwnerIDIssueDate_AR",
          label: "Owners ID Issue Date AR",
          placeholder: "Owners ID Issue Date AR",
          type: "date",
        },
        {
          name: "OwnerIDExpiryDate_EN",
          label: "Owners ID Expiry Date EN",
          placeholder: "Owners ID Expiry Date EN",
          type: "date",
        },
        {
          name: "OwnerIDExpiryDate_AR",
          label: "Owners ID Expiry Date AR",
          placeholder: "Owners ID Expiry Date AR",
          type: "date",
        },
      ],
    },
    {
      heading: "Account Details",

      fields: [
        {
          name: "AccountName_EN",
          label: "Account Name EN",
          placeholder: "Account Name EN",
          type: "text",
        },
        {
          name: "AccountName_AR",
          label: "Account Name AR",
          placeholder: "Account Name AR",
          type: "text",
        },
        {
          name: "AccountNo_EN",
          label: "Account No EN",
          placeholder: "Account No EN",
          type: "text",
        },
        {
          name: "AccountNo_AR",
          label: "Account No AR",
          placeholder: "Account No AR",
          type: "text",
        },
        {
          name: "IBANNo_EN",
          label: "IBAN No EN",
          placeholder: "IBAN No EN",
          type: "text",
        },
        {
          name: "IBANNo_AR",
          label: "IBAN No AR",
          placeholder: "IBAN No AR",
          type: "text",
        },
        {
          name: "SwiftCode_EN",
          label: "Swift Code EN",
          placeholder: "Swift Code EN",
          type: "text",
        },
        {
          name: "SwiftCode_AR",
          label: "Swift Code AR",
          placeholder: "Swift Code AR",
          type: "text",
        },
        {
          name: "BranchName_EN",
          label: "Branch Name EN",
          placeholder: "Branch Name EN",
          type: "text",
        },
        {
          name: "BranchName_AR",
          label: "Branch Name AR",
          placeholder: "Branch Name AR",
          type: "text",
        },
        {
          name: "CityName_EN",
          label: "City Name EN",
          placeholder: "City Name EN",
          type: "text",
        },
        {
          name: "CityName_AR",
          label: "City Name AR",
          placeholder: "City Name AR",
          type: "text",
        },
        {
          name: "CountryName_EN",
          label: "Country Name EN",
          placeholder: "Country Name EN",
          type: "text",
        },
        {
          name: "CountryName_AR",
          label: "Country Name AR",
          placeholder: "Country Name AR",
          type: "text",
        },
        {
          name: "CurrencyName_EN",
          label: "Currency Name EN",
          placeholder: "Currency Name EN",
          type: "dropdown",
          options: [
            { name: "SAR", label: "SAR" },
            { name: "INR", label: "INR" },
            { name: "PKR", label: "PKR" },
          ],
        },
      ],
      button: "Add another Bank",
    },
    {
      heading: "Contact Details",
      fields: [
        {
          name: "ContactPerson_EN",
          label: "Contact Person EN",
          placeholder: "Contact Person EN",
          type: "text",
        },
        {
          name: "ContactPerson_AR",
          label: "Contact Person AR",
          placeholder: "Contact Person AR",
          type: "text",
        },
        {
          name: "Email1",
          label: "Email #1",
          placeholder: "Email #1",
          type: "text",
        },
        {
          name: "Email2",
          label: "Email #2",
          placeholder: "Email #2",
          type: "text",
        },
        {
          name: "MobileNo1_EN",
          label: "#1 Mobile No EN",
          placeholder: "#1 Mobile No EN",
          type: "text",
        },
        {
          name: "MobileNo1_AR",
          label: "Mobile No AR",
          placeholder: "Mobile No AR",
          type: "text",
        },
        {
          name: "MobileNo2_EN",
          label: "#2 Mobile No EN",
          placeholder: "#2 Mobile No",
          type: "text",
        },
        {
          name: "LandlineNo_EN",
          label: "Landline No EN",
          placeholder: "Landline No EN",
          type: "text",
        },
        {
          name: "LandlineNo_AR",
          label: "Landline No AR",
          placeholder: "Landline No AR",
          type: "text",
        },

        {
          name: "POBox_EN",
          label: "PO Box EN",
          placeholder: "PO Box EN",
          type: "text",
        },
        {
          name: "POBox_AR",
          label: "PO Box Name AR",
          placeholder: "PO Box Name AR",
          type: "text",
        },
        {
          name: "ZipCode_EN",
          label: "Zip Code EN",
          placeholder: "Zip Code EN",
          type: "text",
        },
        {
          name: "ZipCode_AR",
          label: "Zip Code AR",
          placeholder: "Zip Code AR",
          type: "text",
        },
      ],
    },
  ];

  const handleInputChange = (name, value) => {
    setRegistrationInput({
      ...registrationInput,
      [name]: value,
    });
  };
  console.log(registrationInput, "rgIp");

  const handleSubmit = async (values, {resetForm, setSubmitting }) => {
    console.log(values, "values");
    try {
      const response = await axios.post(
        // "https:1sdapp.com/api/clientDetails", // Change The API URL #if required
        "https://api.1sdapp.com/api/clientDetails", // Change The API URL #if required
        values
      );
      toast.success(
        `CLIENT HAS BEEN REGISTERED SUCCESSFULLY - UNIQUE ID FOR THE CLIENT IS ${
          response.data.data.uniq_id || ""
        }`);
      console.log(response, "response!", response.data, "response.data");
      resetForm();
    } catch (error) {
      console.log(error, "error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="Client-Registration-container">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
      <div className="flex-1 flex items-center">
         
        <span className="cursor-pointer" onClick={()=>Navigate('/')} >1SD</span>  
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          Client Details
        </div>
        <div className="flex-1 flex gap-5 justify-end">
        <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] "
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" />  */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div onClick={() => Navigate("/")} className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md">
            <FaHome  className=" text-[1.2rem]" />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>
      <div className="clientForm">
        <Formik
          initialValues={initialValues}
          validationSchema={formSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting }) => (
            <Form id="formikForm">
              {RegistrationFields.map((item, index) => (
                <React.Fragment key={index}>
                  <h2 className="col-span-4 mt-3 text-[1.2rem] font-semibold text-[#fff] underline uppercase ">
                    {item.heading}
                  </h2>
                  {item?.fields.map((field, idx) => (
                    <FormikField
                      key={idx}
                      field={field}
                      onChange={(e) =>
                        handleInputChange(e.target.name, e.target.value)
                      }
                    />
                  ))}
                  {item.button && (
                    <button
                      className=" px-8 m-7 bg-white hover:bg-[#4b5563] ease-linear
                                     duration-300 hover:text-white transis border-2 rounded-md h-1/2
                                     tracking-wide font-bold justify-self-center"
                      type="button"
                    >
                      {item.button}
                    </button>
                  )}
                </React.Fragment>
              ))}

              <button
                className="px-1 m-3 bg-white rounded-md text-black tracking-wider font-bold hover:bg-[#4b5563] outline-none border-2
                ease-linear transistion duration-300 hover:text-white "
                type="submit"
              >
                SAVE CLIENT DETAILS
              </button>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default Registration;
