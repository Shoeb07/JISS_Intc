import React, { useEffect, useState } from "react";
import "./Registration.css";
import { Field, Form, Formik } from "formik";
import FormikField from "../../Components/Formik/FormikField";
import * as Yup from "yup";
import axios from "axios";
import DropDown from "../../Components/DropDown/DropDown";
import { toast } from "react-toastify";
import { useNavigate } from "react-router-dom";
import { MdOutlineKeyboardBackspace } from "react-icons/md";
import { FaHome } from "react-icons/fa";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import HijriCalender from "../../Components/HijriCalendar/HijriCalender";
import FormikFieldExp from "../../Components/Formik/FormikFieldExp";
import { validateDate } from "@mui/x-date-pickers/internals";

// import FormInput from "../../Components/FormInput/FormInput";
// import FileInput from "../../Components/FileInput/FileInput";

const Registration = () => {
  const [registrationInput, setRegistrationInput] = useState({});
  const [Country, setCountry] = useState([]);
  const [city, setCity] = useState([]);
  const [mCode, setMCode] = useState();
  const [Currency, setCurrency] = useState();

  const Navigate = useNavigate();

  // console.log(Country, city, mCode, "Valuesssss")

  const isLeapYear = (year) => {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  };

  const dateValidationSchema = Yup.string()
    .nullable() // Allow null or undefined
    .notRequired() // Make the field optional
    .matches(/^\d{4}-\d{2}-\d{2}$/, "Date must be in YYYY-MM-DD format")
    .test("is-valid-date", "Invalid Date", (value) => {
      if (!value) return false; // Ensure value is present

      const [year, month, day] = value.split("-").map(Number);

      // Validate year range
      if (year < 1900 || year > 2100) return false;

      // Validate month and day ranges
      if (month < 1 || month > 12 || day < 1 || day > 31) return false;

      // Check for February and leap year logic
      if (month === 2) {
        if (day > 29) return false;
        if (day === 29 && !isLeapYear(year)) return false;
      }

      // Check for months with 30 days
      if ([4, 6, 9, 11].includes(month) && day > 30) return false;

      // Verify date using JavaScript Date object
      const date = new Date(year, month - 1, day);
      return (
        date.getFullYear() === year &&
        date.getMonth() === month - 1 &&
        date.getDate() === day
      );
    });

  const numberValidation = Yup.string()
    .required("Number is required")
    .matches(/^\+\d+$/, "Invalid Number")
    .test("contains-mcode", "Invalid Country Code", function (value) {
      return value && value.includes(mCode); // Ensure it contains the mcode
    })
    .max(15, "Number cannot exceed 15 characters");

  // const ArabicValidation = Yup.string().matches(
  //   /^[\u0600-\u06FF\u0660-\u0669\s]+$/,
  //   "Only Arabic characters are allowed"
  // );

  // const ArabicValidation = Yup.string()
  // .matches(
  //   /^[\u0600-\u06FF\u0660-\u0669\s]*$/,
  //   "Only Arabic characters and numerals are allowed"
  // )
  // .test("is-valid", "The field must contain Arabic characters or numerals", value => {
  //   // Ensure the value is not empty or only whitespace
  //   return value.trim() === "" || /^[\u0600-\u06FF\u0660-\u0669\s]+$/.test(value);
  // });

  // const ArabicValidation = Yup.string()
  // .matches(
  //   /^[\u0600-\u06FF\u0660-\u0669\s]*$/,
  //   "Only Arabic characters and numerals are allowed"
  // )
  // .test("is-valid", "Only Arabic characters and numerals are allowed", value => {
  //   // Ensure that value only contains Arabic characters, numerals, or whitespace
  //   return /^[\u0600-\u06FF\u0660-\u0669\s]*$/.test(value);
  // });

  const ArabicValidation = Yup.string()
    .matches(
      /^[\u0600-\u06FF\u0660-\u0669\s]*$/,
      "Only Arabic characters and numerals are allowed"
    )
    .test(
      "is-valid",
      "The field must contain Arabic characters or numerals",
      (value) => {
        // Ensure that value contains at least one Arabic character or numeral and is not just whitespace
        return (
          value.trim() === "" || /^[\u0600-\u06FF\u0660-\u0669\s]+$/.test(value)
        );
      }
    );

  // const ArabicMobileNumberValidation = Yup.string()
  // .matches(
  //   /^(\+[\u0600-\u06FF\u0660-\u0669]*[\u0600-\u06FF\u0660-\u0669]*)$/,
  //   "Only Arabic numerals and an optional '+' sign are allowed"
  // )
  // .max(15, "Number cannot exceed 15 characters")
  // .required("Mobile number is required");

  const ArabicMobileNumberValidation = Yup.string()
    .matches(
      /^(\+?[\u0660-\u0669\s]+)$/, // Only Arabic numerals, optional '+', and spaces allowed
      "Invalid Number"
    )
    .max(15, "Number cannot exceed 15 characters") // Ensures maximum length of 15 characters
    .required("Mobile number is required"); // Ensures the field is not empty

  const formSchema = Yup.object().shape({
    unique_id: Yup.string().required("Unique ID is a Required Field"),
    // ShortName_AR: ArabicValidation,
    IssueDate_EN: dateValidationSchema,
    ExpiryDate_EN: dateValidationSchema,
    VATIssueDate_EN: dateValidationSchema,
    VATExpiryDate_EN: dateValidationSchema,
    OwnerIDIssueDate_EN: dateValidationSchema,
    OwnerIDExpiryDate_EN: dateValidationSchema,
    MobileNo1_EN: numberValidation,
    MobileNo2_EN: numberValidation,
    MobileNo1_AR: ArabicMobileNumberValidation,
    LandlineNo_AR: ArabicMobileNumberValidation,

    // CRName_AR: ArabicValidation,
    // UnifiedNo_AR: ArabicValidation,
    // CRNo_AR: ArabicValidation,

    // VATNo_AR: ArabicValidation,
    // VATIssueDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // VATExpiryDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // OwnerName_AR: ArabicValidation,

    // OwnerDOB_AR: Yup.string()
    //   .required("Date is required")
    //   .matches(/^\d{2}-\d{2}-\d{4}$/, "Date must be in the format dd-mm-yyyy")
    //   .test("isValidDate", "Invalid date", (value) => isValidDate(value)),

    // OwnerID_AR: ArabicValidation,
    // OwnerIDIssueDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // OwnerIDExpiryDate_AR : Yup.string().matches(/^[\u0600-\u06FF\s]+$/, "Only Arabic characters are allowed"),
    // AccountName_AR: ArabicValidation,
    // AccountNo_AR: ArabicValidation,
    // IBANNo_AR: ArabicValidation,
    // SwiftCode_AR: ArabicValidation,
    // BranchName_AR: ArabicValidation,
    // CityName_AR: ArabicValidation,
    // ContactPerson_AR: ArabicValidation,
    // MobileNo1_AR: ArabicValidation,
    // LandlineNo_AR: ArabicValidation,
    // POBox_AR: ArabicValidation,
    // ZipCode_AR: ArabicValidation,
  });

  const initialValues = {
    unique_id: "",
    ShortName_EN: "",
    ShortName_AR: "",
    CRName_EN: "",
    CRName_AR: "",
    CRNo_EN: "",
    CRNo_AR: "",
    UnifiedNo_EN: "",
    UnifiedNo_AR: "",
    IssueDate_EN: "",
    IssueDate_AR: "",
    ExpiryDate_EN: "",
    ExpiryDate_AR: "",
    VATNo_EN: "",
    VATNo_AR: "",
    VATIssueDate_EN: "",
    VATIssueDate_AR: "",
    VATExpiryDate_EN: "",
    VATExpiryDate_AR: "",
    OwnerName_EN: "",
    OwnerName_AR: "",
    OwnerDOB_EN: "",
    OwnerDOB_AR: "",
    OwnerID_EN: "",
    OwnerID_AR: "",
    OwnerIDIssueDate_EN: "",
    OwnerIDIssueDate_AR: "",
    OwnerIDExpiryDate_EN: "",
    OwnerIDExpiryDate_AR: "",
    Ac_name_EN: "",
    Ac_name_AR: "",
    Ac_no_EN: "",
    Ac_no_AR: "",
    IBAN_No_EN: "",
    IBAN_No_AR: "",
    swift_EN: "",
    swift_AR: "",
    Branch_name_EN: "",
    Branch_name_AR: "",
    City_name_EN: "",
    City_name_AR: "",
    Country_name_EN: "",
    Currency_name_EN: "",
    ContactPerson_EN: "",
    ContactPerson_AR: "",
    Email1: "",
    Email2: "",
    MobileNo1_EN: "",
    MobileNo2_EN: "",
    MobileNo1_AR: "",
    LandlineNo_EN: "",
    LandlineNo_AR: "",
    POBox_EN: "",
    POBox_AR: "",
    ZipCode_EN: "",
    ZipCode_AR: "",
  };

  const convertToArabicNumerals = (value) => {
    const englishToArabic = {
      0: "٠",
      1: "١",
      2: "٢",
      3: "٣",
      4: "٤",
      5: "٥",
      6: "٦",
      7: "٧",
      8: "٨",
      9: "٩",
    };

    const englishToArabicLetters = {
      a: "ا",
      b: "ب",
      c: "ج",
      d: "د",
      e: "ه",
      f: "ف",
      g: "غ",
      h: "ح",
      i: "ي",
      j: "ج",
      k: "ك",
      l: "ل",
      m: "م",
      n: "ن",
      o: "و",
      p: "ب",
      q: "ق",
      r: "ر",
      s: "س",
      t: "ت",
      u: "ع",
      v: "ف",
      w: "و",
      x: "ش",
      y: "ي",
      z: "ز",
      // Add more mappings as needed
    };
    // Replace each English digit with the corresponding Arabic digit
    // return value.replace(/\d/g, (digit) => englishToArabic[digit]);
    return value.replace(/[a-z0-9]/gi, (char) => {
      if (/[0-9]/.test(char)) {
        return englishToArabic[char] || char;
      }
      return englishToArabicLetters[char.toLowerCase()] || char;
    });
  };

  const handleInputChange = (name, value) => {
    // Convert to Arabic numerals if the field ends with "_AR"
    if (name.endsWith("_AR")) {
      value = convertToArabicNumerals(value);
    }

    // Update Formik field value

    // Update local registration input state
    setRegistrationInput((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleDropDown = (name, value, isSpecial) => {
    console.log(name, value, "dropdown");
    handleInputChange(name, value);
  };

  console.log(registrationInput, "RegistraTION");
  console.log(Currency, typeof Currency, "#currency");

  const RegistrationFields = [
    {
      heading: "Company Registration",
      fields: [
        {
          name: "unique_id",
          label: "Unique ID",
          placeholder: "Unique ID",
          type: "text",
        },
        {
          name: "ShortName_EN",
          label: "Short Name EN",
          placeholder: "Short Name EN",
          type: "text",
        },
        {
          name: "ShortName_AR",
          label: "Short Name AR",
          placeholder: "Short Name AR",
          type: "text",
        },
        {
          name: "CRName_EN",
          label: "CR Name EN",
          placeholder: "CR Name EN",
          type: "text",
        },
        {
          name: "CRName_AR",
          label: "CR Name AR",
          placeholder: "CR Name AR",
          type: "text",
        },
        {
          name: "CRNo_EN",
          label: "CR Number EN",
          placeholder: "CR Number EN",
          type: "text",
        },
        {
          name: "CRNo_AR",
          label: "CR Number AR",
          placeholder: "CR Number AR",
          type: "text",
        },
        {
          name: "UnifiedNo_EN",
          label: "Unified Number EN",
          placeholder: "Unified Number EN",
          type: "text",
        },
        {
          name: "UnifiedNo_AR",
          label: "Unified Number AR",
          placeholder: "Unified Number AR",
          type: "text",
        },
        {
          name: "IssueDate_EN",
          label: "Issue Date EN",
          placeholder: "Issue Date EN",
          type: "date",
        },
        {
          name: "IssueDate_AR",
          label: "Issue Date AR",
          placeholder: "Issue Date AR",
          type: "date_hijri",
        },
        {
          name: "ExpiryDate_EN",
          label: "Expiry Date EN",
          placeholder: "Expiry Date EN",
          type: "date",
        },
        {
          name: "ExpiryDate_AR",
          label: "Expiry Date AR",
          placeholder: "Expiry Date AR",
          type: "date_hijri",
        },
      ],
    },
    {
      heading: "VAT Details",
      fields: [
        {
          name: "VATNo_EN",
          label: "VAT No EN",
          placeholder: "VAT No EN",
          type: "text",
        },
        {
          name: "VATNo_AR",
          label: "VAT No AR",
          placeholder: "VAT No AR",
          type: "text",
        },
        {
          name: "VATIssueDate_EN",
          label: "VAT Issue Date EN",
          placeholder: "VAT Issue Date EN",
          type: "date",
        },
        {
          name: "VATIssueDate_AR",
          label: "VAT Issue Date AR",
          placeholder: "VAT Issue Date AR",
          type: "date_hijri",
        },
        {
          name: "VATExpiryDate_EN",
          label: "VAT Expiry Date EN",
          placeholder: "VAT Expiry Date EN",
          type: "date",
        },
        {
          name: "VATExpiryDate_AR",
          label: "VAT Expiry Date AR",
          placeholder: "VAT Expiry Date AR",
          type: "date_hijri",
        },
      ],
    },
    {
      heading: "Owner Details",
      fields: [
        {
          name: "OwnerName_EN",
          label: "Owners Name EN",
          placeholder: "Owners Name EN",
          type: "text",
        },
        {
          name: "OwnerName_AR",
          label: "Owners Name AR",
          placeholder: "Owners Name AR",
          type: "text",
        },
        {
          name: "OwnerDOB_EN",
          label: "Owners DOB EN",
          placeholder: "Owners DOB EN",
          type: "date",
        },
        {
          name: "OwnerDOB_AR",
          label: "Owners DOB AR",
          placeholder: "Owners DOB AR",
          type: "date_hijri",
        },
        {
          name: "OwnerID_EN",
          label: "Owners ID EN",
          placeholder: "Owners ID EN",
          type: "text",
        },
        {
          name: "OwnerID_AR",
          label: "Owners ID AR",
          placeholder: "Owners ID AR",
          type: "text",
        },
        {
          name: "OwnerIDIssueDate_EN",
          label: "Owners ID Issue Date EN",
          placeholder: "Owners ID Issue Date EN",
          type: "date",
        },
        {
          name: "OwnerIDIssueDate_AR",
          label: "Owners ID Issue Date AR",
          placeholder: "Owners ID Issue Date AR",
          type: "date_hijri",
        },
        {
          name: "OwnerIDExpiryDate_EN",
          label: "Owners ID Expiry Date EN",
          placeholder: "Owners ID Expiry Date EN",
          type: "date",
        },
        {
          name: "OwnerIDExpiryDate_AR",
          label: "Owners ID Expiry Date AR",
          placeholder: "Owners ID Expiry Date AR",
          type: "date_hijri",
        },
      ],
    },
    {
      heading: "Account Details",

      fields: [
        {
          name: "Ac_name_EN",
          label: "Account Name EN",
          placeholder: "Account Name EN",
          type: "text",
        },
        {
          name: "Ac_name_AR",
          label: "Account Name AR",
          placeholder: "Account Name AR",
          type: "text",
        },
        {
          name: "Ac_no_EN",
          label: "Account No EN",
          placeholder: "Account No EN",
          type: "text",
        },
        {
          name: "Ac_no_AR",
          label: "Account No AR",
          placeholder: "Account No AR",
          type: "text",
        },
        {
          name: "IBAN_No_EN",
          label: "IBAN No EN",
          placeholder: "IBAN No EN",
          type: "text",
        },
        {
          name: "IBAN_No_AR",
          label: "IBAN No AR",
          placeholder: "IBAN No AR",
          type: "text",
        },
        {
          name: "swift_EN",
          label: "Swift Code EN",
          placeholder: "Swift Code EN",
          type: "text",
        },
        {
          name: "swift_AR",
          label: "Swift Code AR",
          placeholder: "Swift Code AR",
          type: "text",
        },
        {
          name: "Branch_name_EN",
          label: "Branch Name EN",
          placeholder: "Branch Name EN",
          type: "text",
        },
        {
          name: "Branch_name_AR",
          label: "Branch Name AR",
          placeholder: "Branch Name AR",
          type: "text",
        },
        {
          name: "Country_name_EN",
          label: "Country Name EN",
          placeholder: "Country Name EN",
          type: "dropdown",
          options: [
            { value: "", label: "Select" },
            ...Country.map((item) => ({
              value: item.country,
              label: item.country,
            })),
          ],
        },

        {
          name: "City_name_EN",
          label: "City Name EN",
          placeholder: "City Name EN",
          type: "dropdown",
          options: [
            { value: "", label: "Select" },
            ...city.map((item) => ({
              value: item,
              label: item,
            })),
          ],
        },
        // {
        //   name: "CityName_AR",
        //   label: "City Name AR",
        //   placeholder: "City Name AR",
        //   type: "text",
        // },

        // {
        //   name: "CountryName_AR",
        //   label: "Country Name AR",
        //   placeholder: "Country Name AR",
        //   type: "text",
        // },
        {
          name: "Currency_name_EN",
          label: "Currency Name EN",
          placeholder: "Currency Name EN",
          type: "dropdown",
          options: [
            { name: "", label: "select" },
            { name: Currency, label: Currency },
          ],
        },
      ],
      button: "Add another Bank",
    },
    {
      heading: "Contact Details",
      fields: [
        {
          name: "ContactPerson_EN",
          label: "Contact Person EN",
          placeholder: "Contact Person EN",
          type: "text",
        },
        {
          name: "ContactPerson_AR",
          label: "Contact Person AR",
          placeholder: "Contact Person AR",
          type: "text",
        },
        {
          name: "Email1",
          label: "Email #1",
          placeholder: "Email #1",
          type: "text",
        },
        {
          name: "Email2",
          label: "Email #2",
          placeholder: "Email #2",
          type: "text",
        },
        {
          name: "MobileNo1_EN",
          label: "#1 Mobile No EN",
          placeholder: "#1 Mobile No EN",
          type: "text",
        },
        {
          name: "MobileNo1_AR",
          label: "Mobile No AR",
          placeholder: "Mobile No AR",
          type: "text",
        },
        {
          name: "MobileNo2_EN",
          label: "#2 Mobile No EN",
          placeholder: "#2 Mobile No",
          type: "currency",
        },
        {
          name: "LandlineNo_EN",
          label: "Landline No EN",
          placeholder: "Landline No EN",
          type: "text",
        },
        {
          name: "LandlineNo_AR",
          label: "Landline No AR",
          placeholder: "Landline No AR",
          type: "text",
        },

        {
          name: "POBox_EN",
          label: "PO Box EN",
          placeholder: "PO Box EN",
          type: "text",
        },
        {
          name: "POBox_AR",
          label: "PO Box Name AR",
          placeholder: "PO Box Name AR",
          type: "text",
        },
        {
          name: "ZipCode_EN",
          label: "Zip Code EN",
          placeholder: "Zip Code EN",
          type: "text",
        },
        {
          name: "ZipCode_AR",
          label: "Zip Code AR",
          placeholder: "Zip Code AR",
          type: "text",
        },
      ],
    },
  ];

  useEffect(() => {
    const getAllCountries = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getCountriesCitiesDialCodes"
        );
        const data = response.data.data.data;

        console.log(data, "allDataC");

        let selectedCountry = registrationInput["Country_name_EN"];

        setCountry(data);

        const countryDetails = data?.map((item) => ({
          country: item.country,
          cities: item.cities, // Extracting the cities array
          dialCode: item.dial_code, // Extracting the dial code
          currency: item.currency,
        }));

        const selectedCountryDetails = countryDetails?.find(
          (country) => country.country === selectedCountry
        );

        if (selectedCountryDetails) {
          setCity(selectedCountryDetails?.cities);
          setMCode(selectedCountryDetails?.dialCode);
          setCurrency(selectedCountryDetails?.currency);
          // setRegistrationInput((prevValues) => ({
          //   ...prevValues,
          //   // MobileNo2_EN: mCode,
          // }));
          console.log(mCode, "33code");
        }
      } catch (error) {
        console.log(error);
      }
    };

    getAllCountries(); // Call the function here
  }, [registrationInput.Country_name_EN]);

  const handleSubmit = async (values, { resetForm, setSubmitting }) => {
    console.log(values, "values");
    console.log(values.unique_id, "ID");

    let clubbedData = {
      ...values,
      ...registrationInput,
    };

    try {
      const response = await axios.post(
        "https://api.1sdapp.com/api/ourCompanyDetails", // Change The API URL #if required
        clubbedData
        // jsdata
      );
      console.log(response, "response!", response.data, "response.data");
      toast.success(
        `COMPANY HAS BEEN REGISTERED SUCCESSFULLY - UNIQUE ID FOR THE COMPANY IS ${values.unique_id}`
      );

      resetForm();
    } catch (error) {
      console.log(error, "error");
      toast.error("Internal Server Error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="Registration-container">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          Company Registration
        </div>
        <div className="flex-1 flex justify-end items-center  gap-5">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem]" />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="formContainer">
        <Formik
          initialValues={initialValues}
          validationSchema={formSchema}
          onSubmit={handleSubmit}
        >
          {({
            isSubmitting,
            setFieldValue,
            errors,
            touched,
            values,
            handleBlur,
            handleChange,
          }) => {
            handleChange = (name, value) => {
              if (name.endsWith("_AR")) {
                value = convertToArabicNumerals(value);
              }
              setFieldValue(name, value);
            };
            console.log(values, "#vvv");

            return (
              <Form id="formikForm">
                {RegistrationFields.map((item, index) => (
                  <React.Fragment key={index}>
                    <h2 className="col-span-4 mt-3 text-[1.2rem] font-semibold text-[#fff] underline uppercase ">
                      {item.heading}
                    </h2>

                    {item.fields.map((input, idx) => (
                      <React.Fragment key={idx}>
                        {input.type !== "date_hijri" &&
                          input.type !== "dropdown" && (
                            // <FormikField
                            //   field={input}
                            //   onChange={(e) =>
                            //     handleInputChange(e.target.name, e.target.value)
                            //   }
                            // />

                            // <FormikField
                            //   field={input}
                            //   value={values[input.name]}
                            //   onChange={(event) => {
                            //     handleInputChange(event);
                            //     handleChange(event); // Allow Formik to manage state
                            //   }}
                            //   onBlur={handleBlur}
                            // />

                            // <FormikField
                            //   field={input}
                            //   value={values[input.name]}
                            //   onChange={(event) => {
                            //     handleInputChange(
                            //       event.target.name,
                            //       event.target.value,
                            //       setFieldValue
                            //     );
                            //   }}
                            //   onBlur={handleBlur}
                            // />

                            <FormikField
                              field={input}
                              onChange={(e) => {
                                handleInputChange(input.name, e.target.value);
                                setFieldValue(input.name, e.target.value);
                              }}
                              value={registrationInput[input.name] || ""}
                            />
                          )}

                        {input.type === "dropdown" && (
                          <DropDown
                            name={input.name}
                            options={input.options}
                            label={input.label}
                            // onChange={(e) =>
                            //   handleDropDown(input.name, e.target.value, e)
                            // }
                            onChange={handleDropDown}
                          />
                        )}
                        {input.type === "date_hijri" && (
                          <>
                            <HijriCalender
                              field={input}
                              onChange={handleInputChange}
                            />
                            {/* <Field
                              field={input}
                              component={HijriCalender}
                              onChange={setFieldValue}
                            /> */}
                          </>
                        )}
                      </React.Fragment>
                    ))}
                    {item.button && (
                      <button
                        className=" px-8 m-7 bg-white hover:bg-[#4b5563] ease-linear
                                   duration-300 hover:text-white transis border-2 rounded-md h-1/2
                                   tracking-wide font-bold justify-self-center"
                        type="button"
                      >
                        {item.button}
                      </button>
                    )}
                  </React.Fragment>
                ))}
                <button
                  className="px-1 m-3 bg-white rounded-md text-black tracking-wider font-bold hover:bg-[#4b5563] outline-none border-2
                ease-linear transistion duration-300 hover:text-white "
                  type="submit"
                >
                  SAVE COMPANY DETAILS
                </button>
              </Form>
            );
          }}
        </Formik>
      </div>
    </div>
  );
};

export default Registration;
