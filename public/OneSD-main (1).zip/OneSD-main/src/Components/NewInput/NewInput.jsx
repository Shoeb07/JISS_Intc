import React, { useState } from "react";
import "./NewInput.css";
import axios, { Axios } from "axios";
import { toast } from "react-toastify";

const NewInput = ({
  isOpen,
  catName,
  onClose,
  reload,
  addOfficeExp1,
  addOffice_SubExp,
  catId,
  setAddOffice_SubExp,
  setAddOfficeExp1,
  addClientExp1,
  addClient_SubExp,
  setAddClientExp1,
  setAddClient_SubExp,
  catId_Client,
  addCashTn,
  setaddCashTn,
}) => {
  const [formData, setFormData] = useState({});

  const handleChange = (name, value) => {
    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = async () => {
    try {
      if (addOfficeExp1) {
        const response = await axios.post(
          "https://api.1sdapp.com/api/costCategory",
          {
            catname: formData[catName],
          }
        );
        console.log(response.data, "NewInputErr");
        toast.success("Category Added Successfully");
        setAddOfficeExp1(false);
      }
      if (addOffice_SubExp) {
        let payload = {
          cat_reference: catId,
          subcat_name: formData[catName],
        };

        const response = await axios.post(
          "https://api.1sdapp.com/api/subCostCategory",
          payload
        );
        toast.success("Sub Category Added Successfully");
        setAddOffice_SubExp(false);
      }

      // Client Cat and Sub Cat 👇

      if (addClientExp1) {
        const response = await axios.post(
          "https://api.1sdapp.com/api/costCategoryClient",
          {
            catname: formData[catName],
          }
        );
        console.log(response.data, "NewInputErr");
        toast.success("Category Added Successfully");
        setAddClientExp1(false);
      }
      if (addClient_SubExp) {
        let payload = {
          cat_reference: catId_Client,
          subcat_name: formData[catName],
        };

        const response = await axios.post(
          "https://api.1sdapp.com/api/subCostCategoryClient",
          payload
        );
        toast.success("Sub Category Added Successfully");
        setAddClient_SubExp(false);
      }

      // Add cash Tn 👇

      if (addCashTn) {
        let payload = {
          cash_type: formData[catName],
        };

        const response = await axios.post(
          "https://api.1sdapp.com/api/postCashType",
          payload
        );
        toast.success("Category Added Successfully");
        // setaddCashTn(false);
      }
    } catch (err) {
      console.log(err, "NewInputErr");
    }
    if (reload) {
      reload();
      console.log(reload, "reload");
    }

    if (onClose) {
      onClose();
      console.log(onClose, "onClose");
    }
  };

  console.log(formData, "Input--xx ");

  if (!isOpen) return null;
  return (
    <div className="newInputMain">
      <div className="newInputField">
        <div className="close-button" onClick={onClose}>
          X
        </div>
        <input
          className="outline-none rounded-md p-2"
          type="text"
          placeholder="Enter the value"
          // name={"catname"}
          name={catName}
          // value={formData[catName]}
          onChange={(e) => handleChange(e.target.name, e.target.value)}
        />
        <button className="saveInput" onClick={handleSubmit}>
          Save
        </button>
      </div>
    </div>
  );
};

export default NewInput;
