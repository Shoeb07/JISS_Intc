import { ErrorMessage, Field, useFormikContext } from "formik";
import React from "react";
import "./FormikField.css";

const FormikField = ({ field, readOnly, value, onChange }) => {
  const { setFieldValue } = useFormikContext();

  const handleChange = (event) => {
    const file = event.currentTarget.files[0]; // Get the selected file
    setFieldValue(field.name, file);
    
    console.log(field.name, file)
    // Set the file value in Formik
  };

  return (
    <div className=" flex flex-col m-2 relative">
      <label className="text-white" htmlFor={field?.name}>
        {field?.label}
      </label>

      {field.type === "file" ? (
        <Field
          name={field?.name} >
            {({ field, form }) => (
            <input
              id={field.name}
              name={field.name}
              type="file"
              className=" inputField border-2 border-black outline-none rounded-md"
              // onChange={(event) => {
              //   form.setFieldValue(field.name, event.currentTarget.files[0]);
              // }}
              onChange={handleChange}
            />
          )}
          </Field>

        //   type="file"
        //   onChange={handleChange} // Handle file input change
        //   readOnly={field?.readOnly}
        //   disabled = {field?.disabled}
        //   className=" inputField border-2 border-black outline-none rounded-md"
        // />

      ) : (
        <Field
          name={field?.name}
          type={field?.type}
          readOnly={field?.readOnly}
          className=" inputField border-2 border-black outline-none rounded-md "
          value={value}
          onChange = {onChange}
          // placeholder={field.placeholder}
        />
      )}
      <ErrorMessage name={field?.name} component="div"
       className="error absolute bottom-[-17px] text-red-500 rounded-[3px] bg-gray-900 text-[0.8rem] px-2 font-semibold italic " />
    </div>
  );
};

export default FormikField;
