import React, { useEffect, useState } from "react";
import { MdAddCircleOutline, MdOutlineKeyboardBackspace } from "react-icons/md";
import "./DgCompanies.css";
import { useNavigate } from "react-router-dom";
import { FaHome } from "react-icons/fa";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import axios from "axios";

const DgCompanys = () => {
  const Navigate = useNavigate();

  const [allCompanies, setAllCompanies] = useState();

  useEffect(() => {
    const getOurCompanies = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getOurCompanyDetails"
        );
        console.log(response.data.data);
        setAllCompanies(response.data.data);
      } catch (err) {
        console.log(err, "GetAllCompanies logged an Errro");
      }
    };
    getOurCompanies();
  }, []);

  return (
    <div className="DgCompanys-main">
      {/* <span
            onClick={() => Navigate(-1)}
            className="mr-10 items-center text-[0.9rem] w-fit h-fit flex px-3 gap-2 py-0 rounded-sm cursor-pointer border-2 border-[#004aad] hover:bg-[#004aad] hover:text-white "
          >
            <MdOutlineKeyboardBackspace className="font-bold text-xl" /> 
            back
          </span> */}

      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          // onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          {/* Company Registration */}
        </div>
        <div className="flex-1 flex justify-end items-center  gap-5">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            {/* <IoCaretBackOutline className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("/dglory/Companies/registration")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome
              className=" text-[1.2rem]
              "
            />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div
        className="cards"
        onClick={() => Navigate("/dglory/Companies/registration")}
      >
        <div className="outer flex gap-2 items-center">
          <h2 className="text-xl font-semibold text-white">
            Company Registration{" "}
          </h2>
          <MdAddCircleOutline className="text-xl text-white" />
        </div>
      </div>
      <div className="p-8 w-full h-full">
        <div className="existingCompanies p-4">
          <h2 className="text-xl text-center p-3 uppercase tracking-wider">
            Companies
          </h2>
          <div className="overflow-auto h-[55vh] ">
            <div className=" min-w-[180vw] grid grid-cols-9 whitespace-nowrap w-full gap-4 font-bold text-white bg-gray-800 p-2 rounded overflow-x-auto">
              <div>Unique ID</div>
              <div>Name EN</div>
              <div>Name AR</div>
              <div>Unified No </div>
              <div>CR No</div>
              <div>Expiry Date</div>
              <div>VAT No</div>
              <div>Account Name</div>
              <div>IBAN</div>
            </div>
            {allCompanies?.map((values, id) => (
              <div
                key={id}
                className=" min-w-[180vw] grid grid-cols-9 w-full gap-4 p-2 border-b border-gray-200 overflow-x-auto"
              >
                <div>{values?.unique_id}</div>
                <div>{values?.CRName_EN}</div>
                <div>{values?.CRName_AR}</div>
                <div>{values?.UnifiedNo_EN}</div>
                <div>{values?.CRNo_EN}</div>
                <div>{values?.ExpiryDate_EN}</div>
                <div>{values?.VATNo_EN}</div>
                <div>{values?.Ac_name_EN}</div>
                <div>{values?.IBAN_No_EN}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default DgCompanys;
