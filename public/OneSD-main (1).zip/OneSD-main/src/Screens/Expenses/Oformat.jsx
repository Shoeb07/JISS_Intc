const handleSubmit = (e) => {
  e.preventDefault();
  const data = new FormData(e.target);

  console.log(data, "Raw");

  const payLoadData = Object.fromEntries(data.entries());

  console.log(Object.fromEntries(data.entries()), "submitted");
};


<form className="p-8 bg-gray-600 border-2 rounded-md" onSubmit={handleSubmit}>
  <FormInput
    className="inputField"
    name={"clientName"}
    placeholder={"Client Name EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Client Name AR"}
type={"text"}
/> */}
  <FormInput
    name={"repName"}
    className="inputField"
    placeholder={"REP Name EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"REP Name AR"}
type={"text"}
/> */}
  <FormInput
    name={"vendorName"}
    className="inputField"
    placeholder={"Vendor Name EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Vendor Name AR"}
type={"text"}
/> */}
  <FormInput
    name={"description"}
    className="inputField"
    placeholder={"Description EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Description AR"}
type={"text"}
/> */}
  <FormInput
    name={"paymentStatus"}
    className="inputField"
    placeholder={"Payment Status EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Payment Status AR"}
type={"text"}
/> */}
  <FormInput
    name={"dueAmt"}
    className="inputField"
    placeholder={"Due Amt EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Due Amt AR"}
type={"text"}
/> */}
  <FormInput
    name={"amtBeforeTax"}
    className="inputField"
    placeholder={"Amt Before Tax EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Amt Before Tax AR"}
type={"text"}
/> */}
  <FormInput
    name={"discount"}
    className="inputField"
    placeholder={"Discount EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Discount AR"}
type={"text"}
/> */}
  <FormInput
    name={"vat15%"}
    className="inputField"
    placeholder={"VAT 15% EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"VAT 15% AR"}
type={"text"}
/> */}
  <FormInput
    name={"amt_After_Tax_&_Disc"}
    className="inputField"
    placeholder={"Amt After Tax & Disc. EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Amt After Tax & Disc. AR"}
type={"text"}
/> */}
  <FormInput
    name={"paidAmt"}
    className="inputField"
    placeholder={"Paid Amt EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Paid Amt AR"}
type={"text"}
/> */}
  <FormInput
    name={"paymentMode"}
    className="inputField"
    placeholder={"Payment Mode EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Payment Mode AR"}
type={"text"}
/> */}
  <FormInput
    name={"paymentBank"}
    className="inputField"
    placeholder={"Payment Bank EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Payment Bank AR"}
type={"text"}
/> */}
  <FormInput
    name={"cardType"}
    className="inputField"
    placeholder={"Card Type EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Card Type AR"}
type={"text"}
/> */}
  <FormInput
    name={"paymentDate"}
    className="inputField"
    placeholder={"Payment Date EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Payment Date AR"}
type={"text"}
/> */}
  <FormInput
    name={"monthlyTotal"}
    className="inputField"
    placeholder={"Monthly Total EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Monthly Total AR"}
type={"text"}
/> */}
  <FormInput
    name={"bankAC_details"}
    className="inputField"
    placeholder={"Bank A/C Details EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Bank A/C Details AR"}
type={"text"}
/> */}
  <FormInput
    name={"remarks"}
    className="inputField"
    placeholder={"Remarks EN"}
    type={"text"}
  />
  {/* <FormInput
className="inputField"
placeholder={"Remarks AR"}
type={"text"}
/> */}
  <FormInput
    name={"beneficiary"}
    className="inputField"
    placeholder={"Beneficiary EN"}
    type={"text"}
  />
  {/* <FormInput
  className="inputField"
  placeholder={"Beneficiary AR"}
  type={"text"}
/> */}

  <button className="bg-orange-700 text-white p-2 px-3" type="submit">
    Submit
  </button>
</form>;
