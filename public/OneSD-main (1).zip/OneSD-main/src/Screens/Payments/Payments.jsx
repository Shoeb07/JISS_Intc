import { Form, Formik } from "formik";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";
import DropDown from "../../Components/DropDown/DropDown";
import FormikFieldExp from "../../Components/Formik/FormikFieldExp";
import Textarea from "../../Components/Textarea/Textarea";
import * as Yup from "yup";
import "./Payments.css";

const Payments = () => {
  const Navigate = useNavigate();

  const [formData, setFormData] = useState({});

  const handleDropDown = () => {};

  const handleInputChange = (name, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = async () => {
    console.log("");
  };

  const initialValues = {
    "Expenses Receipt Number": "",
  };

  const PaymentSchema = Yup.object().shape({
    //  "Expenses Receipt Number" : Yup.string.required("This is  a rwquired field")
  });

  const paymentDetails = [
    {
      heading: "Payment Form",
      fields: [
        { name: "search", type: "text", label: "Search" },
        {
          name: "Payment Reference Number",
          label: "Payment Reference Number",
          type: "text",
          readOnly: true,
        },
      ],
    },
    {
      heading: "Basic Information",
      fields: [
        {
          name: "Expenses Receipt Number",
          label: "Expenses Receipt Number",
          type: "text",
        },
      ],
    },
    {
      heading: "Vendor Information",
      fields: [
        {
          name: "Pay To",
          label: "Pay To",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            { value: "", label: "option1" },
            { value: "", label: "option2" },
          ],
        },
        {
          name: "Vendor Info",
          label: "Vendor Info",
          type: "text",
          readOnly: true,
        },
        {
          name: "Vendor Bank",
          label: "Vendor Bank",
          type: "text",
          readOnly: true,
        },
        {
          name: "date",
          label: "Date",
          type: "date",
        },
        {
          name: "Amount",
          label: "Amount",
          type: "text",
        },
        {
          name: "Currency",
          label: "Currency",
          type: "text",
          readOnly: true,
        },
        {
          name: "Paid Through",
          label: "Paid Through",
          type: "text",
        },
        {
          name: "Available Balance",
          label: "Available Balance",
          type: "text",
        },
        {
          name: "Bank Charges (if any)",
          label: "Bank Charges (if any)",
          type: "text",
        },
        {
          name: "payment Type",
          label: "Payment Type",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            { value: "", label: "option1" },
            { value: "", label: "option2" },
          ],
        },
        {
          name: "Description",
          label: "Description",
          type: "textarea",
        },
      ],
    },
  ];

  return (
    <div id="Payment-Section">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          Payments
        </div>
        <div className="flex-1 flex gap-5 justify-end">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem] " />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="formContainer mb-16">
        <Formik
          validationSchema={PaymentSchema}
          initialValues={initialValues}
          onSubmit={handleSubmit}
        >
          <Form id="formikForm">
            {paymentDetails.map((item, index) => (
              <React.Fragment key={index}>
                <h2 className="col-span-4 m-4 ml-0 text-[1.2rem] font-semibold text-[#fff] underline uppercase ">
                  {item.heading}
                </h2>
                {item.fields.map((input, idx) => (
                  <>
                    {input.type === "dropdown" && (
                      <DropDown
                        key={idx}
                        name={input.name}
                        label={input.label}
                        options={input.options}
                        onChange={handleDropDown}
                      />
                    )}

                    {input.type === "text" && (
                      <FormikFieldExp
                        key={index}
                        field={input}
                        value={formData[input.name]}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                    {input.type === "textarea" && (
                      <Textarea
                        name={input.name}
                        label={input.label}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                    {input.type === "date" && (
                      <FormikFieldExp
                        key={index}
                        field={input}
                        value={formData[input.name]}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                  </>
                ))}
              </React.Fragment>
            ))}

            <p></p>
            <button
              className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                          duration-300 hover:text-white transis border-2 rounded-md h-1/2
                         tracking-wide font-bold justify-self-center w-[90%]"
              type="submit"
            >
              SAVE
            </button>
            <button
              className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                          duration-300 hover:text-white transis border-2 rounded-md h-1/2
                         tracking-wide font-bold justify-self-center w-[90%]"
              type="submit"
            >
              SAVE & NEW
            </button>
            <button
              className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                          duration-300 hover:text-white transis border-2 rounded-md h-1/2
                         tracking-wide font-bold justify-self-center w-[90%]"
              type="submit"
            >
              SAVE & CLOSE
            </button>
          </Form>
        </Formik>
      </div>
    </div>
  );
};

export default Payments;
