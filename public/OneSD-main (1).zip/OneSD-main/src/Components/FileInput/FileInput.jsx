import React from 'react'
import "./FileInput.css";

const FileInput = () => {
  return (
    <div className='fileInput' >
        <input type="file" name="file" id="file" />
    </div>
  )
}

export default FileInput