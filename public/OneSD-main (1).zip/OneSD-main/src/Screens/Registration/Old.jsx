<form className="p-8 bg-gray-600 border-2 rounded-md" action="">
<FormInput
  name={"shortNameEN"}
  className="inputField"
  placeholder={"Short Name EN"}
  type={"text"}
/>
<FormInput
name={"shortNameAR"}
  className="inputField"
  placeholder={"Short Name AR"}
  type={"text"}
/>
<FormInput
  name={"CRNameEN"}
  className="inputField"
  placeholder={"CR Name EN"}
  type={"text"}
/>
<FormInput
  name={"CRNameEN"}
  className="inputField"
  placeholder={"CR Name AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"CR Number EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"CR Number AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Unified Number EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Unified Number AR "}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Issue Date EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Issue Date AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Expiry Date EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Expiry Date AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"VAT No EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"VAT No AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"VAT Issue Date EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"VAT Issue Date  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"VAT Expiry Date EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"VAT Expiry Date  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Email #1"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Email #2"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Contact Person EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Contact Person AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Landline No EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Landline No AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"#1 Mobile No EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Mobile No AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"#2 Mobile No"}
  type={"text"}
/>

{/* Owners Details 👇 */}

<h2 className="col-span-4 text-xl mt-4 uppercase tracking-wide text-white font-semibold underline">
  Owners Details
</h2>
<FormInput
  className="inputField"
  placeholder={"Owners Name EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners Name  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners DOB EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners DOB  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners ID EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners ID  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners ID Issue Date EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners ID Issue Date AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners ID Expiry Date EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Owners ID Expiry Date AR"}
  type={"text"}
/>

{/* Bank Details 👇 */}

<h2 className="col-span-4 text-xl mt-4 uppercase tracking-wide text-white font-semibold underline ">
  Bank Details
</h2>
<FormInput
  className="inputField"
  placeholder={"Account Name EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Account Name  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Account No EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Account No  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"IBAN No EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"IBAN No  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Swift Code EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Swift Code  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Branch Name EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Branch Name  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"City Name EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"City Name  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Country Name EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Country Name  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Currency Name EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Currency Name  AR"}
  type={"text"}
/>

{/* Bank Details 👇 */}

<h2 className="col-span-4 text-xl mt-4 uppercase tracking-wide text-white font-semibold underline ">
  Address
</h2>
<FormInput
  className="inputField"
  placeholder={"PO Box EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"PO Box Name  AR"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Zip Code EN"}
  type={"text"}
/>
<FormInput
  className="inputField"
  placeholder={"Zip Code  AR"}
  type={"text"}
/>

 <FileInput/>

<div className="mt-5 col-span-4">
  <button
    className="w-1/2 h-[7vh] rounded-md font-semibold"
    id="RegistrationBtn"
  >
    SAVE
  </button>
</div>
</form>