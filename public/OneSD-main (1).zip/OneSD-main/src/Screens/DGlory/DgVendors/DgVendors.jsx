import axios from "axios";
import React, { useEffect, useState } from "react";
import { MdAddCircleOutline, MdOutlineKeyboardBackspace } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import "./DgVendors.css";
import { FaHome } from "react-icons/fa";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";

const DgVendors = () => {
  const [venData, setVenData] = useState();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllVendorDetails"
        );
        console.log(response.data, "venResponse");
        setVenData(response?.data.data);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, []);

  const Navigate = useNavigate();

  return (
    <div className="DgVendors-main">
      {/* <span
            onClick={() => Navigate(-1)}
            className="mr-10 items-center text-[0.9rem] w-fit h-fit flex px-3 gap-2 py-0 rounded-sm cursor-pointer border-2 border-[#004aad] hover:bg-[#004aad] hover:text-white "
          >
            <MdOutlineKeyboardBackspace className="font-bold text-xl" /> 
            back
          </span> */}

      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center mb-[30px]">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          // onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          {/* Company Registration */}
        </div>
        <div className="flex-1 flex justify-end items-center  gap-5">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            {/* <IoCaretBackOutline className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("/dglory/vendorsRegistration")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div onClick={() => Navigate("/")} className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md">
            <FaHome  className=" text-[1.2rem]" />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div
        className="cards"
        onClick={() => Navigate("/dglory/vendorsRegistration")}
      >
        <div className="outer flex gap-2 items-center">
          <h2 className="text-xl font-semibold text-white">
            Vendors Registration{" "}
          </h2>
          <MdAddCircleOutline className="text-xl text-white" />
        </div>
      </div>
      <div className="p-8 w-full h-full">
        <div className="VendorsList  p-4">
          <h2 className="text-xl text-center p-3 uppercase tracking-wider text-white">
            Vendors
          </h2>
          <div className="grid grid-cols-5 gap-4 font-bold text-white bg-gray-800 p-2 rounded">
            <div>Unique ID</div>
            <div>Company Name</div>
            <div>Short Name</div>
            <div>POC</div>
            <div>Email</div>
          </div>
          {venData?.map((values, id) =>  (
              <div
              key={id}
              className="grid text-white grid-cols-5 gap-4 p-2 border-b border-gray-200"
            >
              {console.log(values, 'idx3')}
              <div> {values?.uniq_id}</div>
              <div> {values?.ven_name} </div>
              <div>{values?.ven_shortname}</div>
              <div>{values?.ven_pofcon}</div>
              <div> {values?.ven_Email_add} </div>
               
            </div>
            )
          )}
        </div>
      </div>
    </div>
  );
};

export default DgVendors;
