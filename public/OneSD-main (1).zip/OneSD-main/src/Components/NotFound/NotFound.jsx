import React from 'react';
import { useNavigate } from 'react-router-dom';

const NotFound = () => {
  const history = useNavigate();

  const handleGoHome = () => {
    history('/'); 
  };

  const handleGoBack = () => {
    history(-1);
  };

  return (
    <div className="flex flex-col items-center justify-center h-screen bg-[#0e1a2f] text-white text-center font-sans">
      <h1 className="text-6xl m-0">404</h1>
      <p className="text-2xl">Oops! Lost in Space!</p>
      <button
        className="button mt-4 px-6 py-3 text-lg text-white bg-orange-500 rounded-md transition ease-in-out duration-300 hover:bg-orange-600"
        onClick={handleGoHome}
      >
        🏠 Go to Home
      </button>
      <button
        className="button mt-4 px-6 py-3 text-lg text-white bg-[#cdcccc4e] rounded-md transition ease-in-out duration-300 hover:bg-white hover:text-[#0e1a2f]"
        onClick={handleGoBack}
      >
        🔙 Go Back
      </button>
    </div>
  );
};

export default NotFound;
