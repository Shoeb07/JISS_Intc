import axios from "axios";
import React, { useEffect, useState } from "react";
import { MdAddCircleOutline, MdOutlineKeyboardBackspace } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { toast } from "react-toastify";
import "./DgClients.css";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";

const DgClients = () => {
  const Navigate = useNavigate();
  const [cData, setCData] = useState();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const res = await axios.get(
          // "https://1sdapp.com/api/getAllClientDetails"
          "https://api.1sdapp.com/api/getAllClientDetails"
        );
        console.log(res.data);
        setCData(res.data.data);
      } catch (err) {
        console.log(err);
        toast.error("Internal Server Error");
      }
    };
    fetchData();
  }, []);

  return (
    <div className="DgCompanys-main">
     

      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          // onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          {/* Company Registration */}
        </div>
        <div className="flex-1 flex justify-end items-center  gap-5">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            {/* <IoCaretBackOutline className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("/dglory/clients/registration")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem]" />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div
        className="cards"
        onClick={() => Navigate("/dglory/clients/registration")}
      >
        <div className="outer flex gap-2 items-center">
          <h2 className="text-xl font-semibold text-white">
            Client Registration{" "}
          </h2>
          <MdAddCircleOutline className="text-xl text-white" />
        </div>
      </div>
      
      <div className="p-8 w-full h-full">
        <div className="existingCompanies p-4">
          <h2 className="text-xl text-center p-3 uppercase tracking-wider">
          Client
          </h2>
          <div className="grid grid-cols-5 gap-4 font-bold text-white bg-gray-800 p-2 rounded">
            <div>Unique ID</div>
            <div>Short Name</div>
            <div>Contact Person</div>
            <div>Email </div>
            <div>Mobile No</div>
          </div>
          {cData?.map((values, id) => (
            <div
              key={id}
              className="grid grid-cols-5 gap-4 p-2 border-b border-gray-200"
            >
              <div>{values?.uniq_id}</div>
              <div>{values?.ShortName_EN}</div>
              <div>{values?.ContactPerson_EN}</div>
              <div>{values?.Email1}</div>
              <div>{values?.MobileNo1_EN}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DgClients;
