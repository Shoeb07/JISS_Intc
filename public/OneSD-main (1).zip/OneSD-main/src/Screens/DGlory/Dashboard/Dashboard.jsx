import React from "react";
import { MdAddCircleOutline, } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import "./Dashboard.css";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";
const Dashboard = () => {
  const Navigate = useNavigate();

  return (
    <div className="Dashboard-Main">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          DGLORY
        </div>
        <div className="flex-1 flex justify-end gap-5">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] "
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem]" />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="content">
        <div className="cards" onClick={() => Navigate("/dglory/Companies")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Companies</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("/dglory/vendors")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Vendors</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("/dglory/clients")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Clients</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Client PO</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
    
        <div className="cards" onClick={() => Navigate("/dglory/ProposalsScreen")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Proposals</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>{" "}
        </div>
        <div className="cards" onClick={() => Navigate("/dglory/ProjectsScreen")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Projects</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div
          className="cards"
          onClick={() => Navigate("/dglory/expensesScreen")}
        >
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Cash / Credit Expenses</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("/payments")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Payments</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Refunds / Credits</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Quotes</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Invoices</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("/purchaseOrder")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Purchase Orders</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Inventory</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Banks / Credit Cards</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">HR</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Reports</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Receive Payments</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
        <div className="cards" onClick={() => Navigate("")}>
          <div className="outer">
            <h2 className="text-xl font-semibold text-white">Time Sheets</h2>
            <MdAddCircleOutline className="text-xl text-white" />
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
