import { Form, Formik } from "formik";
import React, { useState } from "react";
import FormikField from "../../Components/Formik/FormikField";
import "./VendorReg.css";
import axios from "axios";
import * as Yup from "yup";
import { toast } from "react-toastify";
import { MdOutlineKeyboardBackspace } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";
import FormikFieldExp from "../../Components/Formik/FormikFieldExp";

const VendorReg = () => {
  const [vatStatus, setVatStatus] = useState("registered");

  const Navigate = useNavigate();

  const vendorSchema = Yup.object().shape({
    // ven_name: Yup.string().required('Client Name Is Required'),
    ven_nameAR: Yup.string().matches(
      /^[\u0600-\u06FF\s]+$/,
      "Only Arabic characters are allowed"
    ),
  });

  const initialValues = {
    ven_unique_id: "",
    ven_name: " ",
    ven_shortname: " ",
    ven_Cr_no: "",
    ven_Vat_no: "",
    ven_Vat_type: "",
    ven_Bank_name: "",
    ven_Benef_name: "",
    ven_AC_no: "",
    ven_IBAN_no: "",
    ven_alt_con1: "",
    ven_alt_con2: "",
    ven_Email_add: " ",
    ven_mailAdd: "",
    ven_website: "",
    ven_google_link: "",
    ven_city: "",
    ven_country: "",
    ven_Telephone: "",
    ven_Notes: "",
    ven_Remark: "",
    ven_pofcon: "",
    ven_pofcon2: "",
    uploadFile: "",
    Vat: "",
    cr_file: null,
    Vat_file: null,
    bank_file: null,
    business_file: null,
    iqama_file: null,
    liscense_file: null,
    istemara_file: null,
  };

  const fieldDefinitions = [
    {
      heading: "Vendor Details",
      fields: [
        // {
        //   name: "ven_unique_id",
        //   label: "Unique ID",
        //   type: "text",
        //   readOnly: true,
        // },
        {
          name: "ven_shortname",
          label: "Short Name",
          type: "text",
        },
        { name: "ven_name", label: "Registered Name ENG", type: "text" },
        { name: "ven_nameAR", label: "Registered Name AR", type: "text" }, // key need to changed
        { name: "ven_Cr_no", label: "CR ", type: "tel" },
        { name: "ven_Vat_no", label: "VAT  ", type: "tel" },
        { name: "ven_Vat_type", label: "Vendor Type", type: "text" }, //Need to add a key For VAT Type
      ],
    },
    {
      heading: "Bank Details",
      fields: [
        { name: "ven_Bank_name", label: "Bank Name", type: "text" },
        { name: "ven_Benef_name", label: "Beneficiary Name", type: "text" },
        { name: "ven_AC_no", label: "A/C Number", type: "tel" },
        { name: "ven_IBAN_no", label: "IBAN Number", type: "tel" },
        { name: "ven_IBAN_CRN", label: "Currency", type: "tel" }, // key Changed
      ],
    },
    {
      heading: "Other Info",
      fields: [
        { name: "ven_alt_con1", label: "Mobile 1", type: "tel" },
        { name: "ven_alt_con2", label: "Mobile 2", type: "tel" },
        { name: "ven_Email_add", label: "Email 1", type: "email" },
        { name: "ven_mailAdd", label: "Email 2", type: "email" },
        { name: "ven_website", label: "Website", type: "url" },
        {
          name: "ven_google_link",
          label: "Google Link (location)",
          type: "text",
        },
        { name: "ven_Addr", label: "Address", type: "text" }, // key changed
        { name: "ven_city", label: "City", type: "text" },
        { name: "ven_country", label: "Country", type: "text" },
        { name: "ven_Telephone", label: "Landline NO.", type: "tel" }, // key
        { name: "ven_Suplyinfo", label: "Vendor Supplies Info", type: "text" }, // key Changed
        { name: "ven_Notes", label: "Notes", type: "text" },
        { name: "ven_Remark", label: "Remarks", type: "text" },
        {
          name: "ven_pofcon",
          label: "contact Name 1",
          type: "text",
        },
        {
          name: "ven_pofcon2",
          label: "contact Name 2", //key Changed
          type: "text",
        },
      ],
    },
    {
      heading: "Attachments",
      fields: [
        { name: "cr_file", label: "CR", type: "file" },
        { name: "Vat_file", label: "VAT", type: "file" },
        { name: "bank_file", label: "Bank A/C", type: "file" },
        { name: "business_file", label: "Business Card", type: "file" },
        { name: "iqama_file", label: "Iqama", type: "file" },
        { name: "liscense_file", label: "License", type: "file" },
        { name: "istemara_file", label: "Istemara", type: "file" },
      ],
    },
  ];

  const handleSubmit = async (values, { resetForm, setSubmitting }) => {
    console.log(values, "valll");
    try {
      const response = await axios.post(
        "https://api.1sdapp.com/api/vendorDetails",
        values
      );
      console.log(response, "Expenses-Responses");
      toast.success(
        `VENDOR HAS BEEN REGISTERED SUCCESSFULLY - UNIQUE ID FOR THE VENDOR IS ${
          response.data.data.uniq_id || ""
        }`
      );
      resetForm();
    } catch (err) {
      console.log(err);
      toast.error("Internal Server Error");
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="Vendor-Section">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>{" "}
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer"
        >
          {" "}
          Vendor Registration
        </div>
        <div className="flex-1 flex gap-5 justify-end">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] "
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate(1)}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem]" />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="formContainer mb-16">
        <Formik
          initialValues={initialValues}
          validationSchema={vendorSchema}
          onSubmit={handleSubmit}
        >
          {({ values }) => (
            <Form id="formikForm">
              <>
                <div className="VAT-SELECTION  mb-4">
                  <label className="text-white font-semibold uppercase underline ">
                    Vendor Registration:
                  </label>
                  <select
                    className="border-2 px-3 py-2 ml-2 text-[1rem] mt-4"
                    value={vatStatus}
                    onChange={(e) => setVatStatus(e.target.value)}
                  >
                    <option value="registered">VAT Registered</option>
                    <option value="notRegistered"> Non VAT Registered</option>
                  </select>
                </div>
                {fieldDefinitions.map((group, index) => (
                  <React.Fragment className="mb-3 " key={index}>
                    <h2 className="col-span-4 text-white font-semibold uppercase underline  ">
                      {group.heading}
                    </h2>
                    {group.fields.map((field, index) => (
                      <>
                        {field.name.includes("Vat") &&
                        vatStatus !== "registered" ? null : (
                          <>
                            <FormikField key={index} field={field} />
                            {field.name === "file" && (
                              <FormikFieldExp key={index} field={field} />
                            )}
                          </>
                        )}
                      </>
                    ))}
                  </React.Fragment>
                ))}

                <button
                  className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                      duration-300 hover:text-white transis border-2 rounded-md h-1/2
                     tracking-wide font-bold justify-self-center"
                  type="submit"
                >
                  SAVE VENDOR DETAILS
                </button>
              </>
            </Form>
          )}
        </Formik>
      </div>
    </div>
  );
};

export default VendorReg;
