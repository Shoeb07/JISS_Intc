import { Route, Routes } from "react-router-dom";
import "./index.css";
import LandingPage from "./Screens/LandingPage/LandingPage";
// import Dglory from "./Screens/DGlory/Dglory";
import Registration from "./Screens/Registration/Registration";
import Expenses from "./Screens/Expenses/Expenses";
import VendorReg from "./Screens/VendorRegistration/VendorReg";
import ClientRegistration from "./Screens/ClientRegistration/ClientRegistration";
import Dashboard from "./Screens/DGlory/Dashboard/Dashboard";
import DgCompanys from "./Screens/DGlory/DgCompanies/DgCompanies";
import DgExpensesScreen from "./Screens/DGlory/DgExpensesScreen/DgExpensesScreen";
import DgVendors from "./Screens/DGlory/DgVendors/DgVendors";
import DgClients from "./Screens/DGlory/DgClients/DgClients";
import CustomizedTable from "./Components/CustomizedTable/CustomizedTable";
import Project from "./Screens/Project&PO/Project";
import Proposal from "./Screens/Project&PO/Proposal";
import NotFound from "./Components/NotFound/NotFound";
import Payments from "./Screens/Payments/Payments";
import PurchaseOrder from "./Screens/PurchaseOrder/PurchaseOrder";
import DgProjects from "./Screens/DGlory/DgProjects/DgProjects";
import DgProposals from "./Screens/DGlory/DgProposals/DgProposals";
 

function App() {
  return (
    <div className="Main-Container">
      <Routes>
        <Route path={"/"} element={<LandingPage />} />
        <Route path={"/dglory"} element={<Dashboard />} />
        <Route path={"/dglory/Companies"} element={<DgCompanys />} />
        <Route path={"/dglory/expensesScreen"} element={<DgExpensesScreen />} />
        <Route path={"/dglory/vendors"} element={<DgVendors />} />
        <Route path={"/dglory/clients"} element={<DgClients />} />
        <Route path={"/dglory/table"} element={<CustomizedTable />} />
        <Route path={"/dglory/project"}  element={<Project/>} />
        <Route path={"/dglory/po"} element={<Proposal/>} />
        <Route path={"/dglory/ProjectsScreen"} element={<DgProjects/>} />
        <Route path={"/dglory/ProposalsScreen"} element={<DgProposals/>} />
        
        <Route path={"/dglory/Companies/registration"} element={<Registration />} />
        <Route path={"/dglory/expenses"} element={<Expenses />} />
        <Route path={"/dglory/vendorsRegistration"} element={<VendorReg />} />
        <Route path={"/dglory/clients/registration"} element={<ClientRegistration />} />
        <Route path={"/payments"} element={<Payments />} />
        <Route path={"/purchaseOrder"} element={<PurchaseOrder />} />
        <Route path="*" element={<NotFound/>} />
      </Routes>
    </div>
  );
}

export default App;
