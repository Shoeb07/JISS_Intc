import React from "react";

const DataList = ({ name, label, placeholder, options, value, onChange }) => {
  return (
    <div className="flex flex-col  m-2">
      <label htmlFor={name}>{label}</label>
      <input
        list={`${name}-options`}
        id={name}
        name={name}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        className="text-input-dropdown"
      />
      <datalist
       className=" inputField border-2 border-black outline-none rounded-md  "
      id={`${name}-options`}>
        {options.map((option, index) => (
          <option key={index} value={option.value}>
            {option.label}
          </option>
        ))}
      </datalist>
    </div>
  );
};

export default DataList;
