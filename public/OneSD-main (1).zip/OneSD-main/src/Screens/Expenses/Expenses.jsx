import React, { useEffect, useMemo, useState } from "react";
import FormInput from "../../Components/FormInput/FormInput";
import "./Expenses.css";
import { Form, Formik } from "formik";
import FormikField from "../../Components/Formik/FormikField";
import axios from "axios";
import * as Yup from "yup";
import { toast } from "react-toastify";
import DropDown from "../../Components/DropDown/DropDown";
import Modal from "../../Components/Modal/Modal";
import { useNavigate } from "react-router-dom";
import FormikFieldExp from "../../Components/Formik/FormikFieldExp";
import Textarea from "../../Components/Textarea/Textarea";
import NewInput from "../../Components/NewInput/NewInput";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";

const Expenses = () => {
  const Navigate = useNavigate();
  const [disable, setDisable] = useState(false);
  const [clientCat, setClientCat] = useState(false);
  const [formData, setFormData] = useState({});
  const [vendorsList, setVendorsList] = useState([]);
  const [clientList, setClientList] = useState([]);
  const [companyList, setCompanyList] = useState([]);
  const [projectList, setProjectList] = useState([]);
  const [poList, setPoList] = useState([]);

  const [allCashTn, setAllCashTn] = useState([]);
  const [addCashTn, setaddCashTn] = useState(false);

  const [allCategory, setAllCategory] = useState([]);
  const [allCategory_Client, setAllCategory_Client] = useState([]);
  const [catId, setCatId] = useState();
  const [catId_Client, setCatId_Client] = useState();

  const [closeExp, setCloseExp] = useState(false);

  const [displayModal, setDisplayModal] = useState(false);

  const [addOfficeExp1, setAddOfficeExp1] = useState(false);
  const [addOffice_SubExp, setAddOffice_SubExp] = useState(false);
  const [addClientExp1, setAddClientExp1] = useState(false);
  const [addClient_SubExp, setAddClient_SubExp] = useState(false);

  const [catName, setCatName] = useState("");
  const [reloadKey, setReloadKey] = useState(0); // A key to trigger useEffect

  const reload = () => {
    setReloadKey((prevKey) => prevKey + 1);
    // Increment reloadKey to trigger useEffect
  };

  const handleInputChange = (name, value) => {
    // console.log(name, value, "sc check2");
    setFormData({
      ...formData,
      [name]: value,
    });
  };
  const [selectedPaymentMode, setSelectedPaymentMode] = useState("");
  const [costCenter, setCostCenter] = useState("");

  const handleDropDown = (name, value, isSpecial) => {
    handleInputChange(name, value);

    const category = allCategory.find((cat) => cat.cat_name === value); //storing the cat catId term
    const categoryClient = allCategory_Client.find(
      (cat) => cat.cat_name === value
    ); //storing the client catId term

    if (name === "pay_mode" || isSpecial === true) {
      // console.log(name, "credit$");
      setSelectedPaymentMode(value);
      // setShowModal(true);
    }

    if (name === "cc_exp_cat") {
      setCostCenter(value);
      // console.log(value, "ExpensesCC$");
    }

    // Add Cash Tn 👇

    if (name === "cash" && value === "Add New Payment") {
      setDisplayModal(true);
      setaddCashTn(true);
      setCatName(name);
      console.log("mainCat = ", name);
      setSelectedPaymentMode(name);
    }

    // Update Cost Center 👇

    if (name === "officeExpense" && value === "Add Office Expense") {
      setDisplayModal(true);
      setAddOfficeExp1(true);
      setCatName(name);
      console.log("mainCat = ", name);
    }
    if (name === "officeExpense" && value === "Add Office Sub Expense") {
      setDisplayModal(true);
      setAddOffice_SubExp(true);
      setCatName(name);
      console.log("subCat = ", name);
    }
    if (name === "ClientExpensesCategory" && value === "Add Client Expense") {
      setDisplayModal(true);
      setAddClientExp1(true);
      setCatName(name);
      console.log("mainCat = ", name);
    }
    if (
      name === "ClientExpensesCategory" &&
      value === "Add Client Sub Expense"
    ) {
      setDisplayModal(true);
      setAddClient_SubExp(true);
      setCatName(name);
      console.log("subCat = ", name);
    }

    if (category) {
      setCatId(category.cat_id); // storing Cat Id
    }
    if (categoryClient) {
      setCatId_Client(categoryClient.cat_id); // storing Cat Id
    }

    if (value === "clientExpenses") {
      setCostCenter("clientExpenses");
    }

    if (name === "Business_name" && value === "Add a New Business") {
      // console.log("open businessssss TAG");
      Navigate("/dglory/Companies/registration");
    }

    if (name === "Clients_name" && value === "Add Client") {
      // console.log("open businessssss TAG");
      Navigate("/dglory/clients/registration");
    }

    if (name === "Vendor_name" && value === "Add Vendor") {
      // console.log("open businessssss TAG");
      Navigate("/dglory/vendorsRegistration");
    }
    if (name === "Project_Po" && value === "Add Project") {
      Navigate("/dglory/project");
    }
    if (name === "Project_Po" && value === "Add PO") {
      Navigate("/dglory/po");
    }
    if (name === "pay_mode" && value === "cash") {
      setDisable(true);
    }

    if (name === "pay_mode" && value === "credit") {
      setDisable(false);
    }

    // console.log(name, value, isSpecial, "handleDrop");
  };

  const ExpensesSchema = Yup.object().shape({
    // clientName : Yup.string().required('This is required');
  });

  const initialValues = {
    // Expenses Form
    Business_name: "",
    Clients_name: "",
    Project_Po: "",

    // Invoice Details
    Vendor_name: "",
    invoice_date: "",
    invoice_no: "",
    description: "",
    amount_befor_VAT: "",
    VAT_per: "",
    VATAmount: "",
    Currency: "",
    total_with_VAT: "",

    // Cost Center
    cc_exp_cat: "",
    officeExpense: "",
    clientExpenses: "",
    ClientExpensesCategory: "",

    // Invoice Status
    pay_mode: "",
    cash: " ",
    credit: "",

    // Additional Notes
    emp_id: "",
    Pay_priority: "",
    notes: "",
  };

  useEffect(() => {
    const calculateVAT = () => {
      const amountBeforeVAT = parseFloat(formData["amount_befor_VAT"]) || 0;
      const vatPercentage = parseFloat(formData["VAT_per"]) || 0;
      const vatAmount = (amountBeforeVAT * vatPercentage) / 100;
      const totalAmountWithVAT = amountBeforeVAT + vatAmount;

      setFormData((prevData) => ({
        ...prevData,
        VATAmount: vatAmount.toFixed(2),
        total_with_VAT: totalAmountWithVAT.toFixed(2),
      }));
      // console.log(amountBeforeVAT, "amountBeforeVAT ");
      // console.log(vatPercentage, "vatttt %");
      // console.log(vatAmount, "vatAmount");
      // console.log(totalAmountWithVAT, "totalAmountWithVAT");
    };

    calculateVAT();
  }, [formData["amount_befor_VAT"], formData["VAT_per"]]);

  useEffect(() => {
    const BusinessName = formData["Business_name"];
    if (
      BusinessName === "DGLORY" ||
      BusinessName === "BAKSH" ||
      BusinessName === "WAM"
    ) {
      setFormData((prevData) => ({
        ...prevData,
        Currency: "SAR",
      }));
    } else if (BusinessName === "AL MUKAAB") {
      setFormData((prevData) => ({
        ...prevData,
        Currency: "BHD",
      }));
    } else if (BusinessName === "JISS") {
      setFormData((prevData) => ({
        ...prevData,
        Currency: "INR",
      }));
    } else {
      setFormData((prevData) => ({
        ...prevData,
        Currency: "",
      }));
    }
  }, [formData["Business_name"]]);

  useEffect(() => {
    const getVendors = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllVendorDetails"
        );
        const data = response.data.data;

        const options = data
          .filter(
            (vendor) =>
              vendor.ven_shortname && vendor.ven_shortname.trim() !== ""
          )
          .map((vendor) => ({
            value: vendor.ven_shortname,
            label: vendor.ven_shortname,
          }));

        setVendorsList(options);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getVendors();
  }, []);

  useEffect(() => {
    const getCompanies = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getOurCompanyDetails"
        );
        const data = response.data.data;

        const options = data
          .filter(
            (company) =>
              company.ShortName_EN && company.ShortName_EN.trim() !== ""
          )
          .map((company) => ({
            value: company.ShortName_EN,
            label: company.ShortName_EN,
          }));

        setCompanyList(options);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getCompanies();
  }, []);
  useEffect(() => {
    const getClients = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllClientDetails"
        );
        const data = response.data.data;

        const options = data
          .filter(
            (client) => client.ShortName_EN && client.ShortName_EN.trim() !== ""
          )
          .map((client) => ({
            value: client.ShortName_EN,
            label: client.ShortName_EN,
          }));

        setClientList(options);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getClients();
  }, []);
  useEffect(() => {
    const getProjects = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllProjectDetails"
        );
        const data = response.data.data;

        const options = data
          .filter(
            (project) =>
              project.Project_title && project.Project_title.trim() !== ""
          )
          .map((project) => ({
            value: project.Project_title,
            label: project.Project_title,
          }));

        setProjectList(options);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getProjects();
  }, []);

  useEffect(() => {
    const getProposals = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllProposals"
        );
        const data = response.data.data;

        const options = data
          .filter(
            (project) =>
              project.Project_title && project.Project_title.trim() !== ""
          )
          .map((project) => ({
            value: project.Project_title,
            label: project.Project_title,
          }));

        setPoList(options);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getProposals();
  }, []);

  useEffect(() => {
    const getAllCategory = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllCostCategoriesAndSubCategories"
        );
        setAllCategory(response.data.data);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getAllCategory();
  }, [reloadKey]);

  useEffect(() => {
    const getAllCategory_clients = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllCostCategoriesAndSubCategoriesClient"
        );
        setAllCategory_Client(response.data.data);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getAllCategory_clients();
  }, [reloadKey]);

  useEffect(() => {
    const getallCashTn = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllCashTypes"
        );
        setAllCashTn(response.data.data);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getallCashTn();
  }, [reloadKey]);

  const ExpensesFields = [
    {
      heading: "Expenses Form",
      fields: [
        // {
        //   name: "uniq_id",
        //   label: "Unique ID",
        //   type: "text",
        // },
        {
          name: "Business_name",
          label: "Business Name",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            ...companyList,
            { value: "DGLORY", label: "DGLORY" },
            { value: "BAKSH", label: "BAKSH" },
            { value: "WAM", label: "WAM" },
            { value: "AL MUKAAB", label: "AL MUKAAB" },
            { value: "JISS", label: "JISS" },
            {
              value: "Add a New Business",
              label: "Add a New Business ",
              isSpecial: true,
            },
          ],
        },
        {
          name: "Clients_name",
          label: "Clients",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            ...clientList,
            { value: "Binladen Group", label: "Binladen Group" },
            { value: "Khorasani Group", label: "Khorasani Group" },
            {
              value: "Add Client",
              label: "Add Client ",
              isSpecial: true,
            },
          ],
        },
        {
          name: "Project_Po",
          label: "Project / PO",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            ...projectList,
            ...poList,
            { value: "Defence System", label: "Defence System" },
            { value: "Test System", label: "Test System" },
            {
              value: "Add Project",
              label: "Add Project",
              isSpecial: true,
            },
            {
              value: "Add PO",
              label: "Add PO",
              isSpecial: true,
            },
          ],
        },
      ],
    },
    {
      heading: "Invoice Details",
      fields: [
        {
          name: "Vendor_name",
          label: "Vendor Name",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            ...vendorsList,
            {
              value: "Osama Tech",
              label: "Osama Tech",
            },
            { value: "Saifullah Group", label: "Saifullah Group" },
            {
              value: "Add Vendor",
              label: "Add Vendor ",
              isSpecial: true,
            },
          ],
        },
        { name: "invoice_date", label: "Invoice Date", type: "date" },
        { name: "invoice_no", label: "Invoice No", type: "text" },
        { name: "description", label: "Description", type: "textarea" },
        {
          name: "amount_befor_VAT",
          label: "Amount Before VAT",
          type: "text",
        },
        {
          name: "VAT_per",
          label: "VAT Percentage %",
          type: "text",
          // type: "dropdown",
          // options: [
          //   { value: "0%", label: "0%" },
          //   { value: "5%", label: "5%" },
          //   { value: "10%", label: "10%" },
          //   { value: "15%", label: "15%" },
          // ],
        },
        {
          name: "VATAmount",
          label: "VAT Amount",
          type: "text",
          readOnly: true,
        },
        { name: "Currency", label: "Currency", type: "text", readOnly: true },
        {
          name: "total_with_VAT",
          label: "Total Amount with VAT",
          type: "text",
          readOnly: true,
        },
      ],
    },
    {
      heading: "Cost Center",
      fields: [
        {
          name: "cc_exp_cat",
          label: "Expenses",
          type: "dropdown",
          options: [
            { value: "select", label: "select" },

            {
              nameC: "cc_ofcexp_cat1",
              value: "officeExpense",
              label: "Office Expenses",
            },
            { value: "clientExpenses", label: "Client Expenses" },
          ],
        },
        {
          name: "officeExpense",
          label: "Office Expenses",
          type: "dropdown",
          options: [
            { value: "select", label: "select" },
            ...allCategory?.map((item) => ({
              value: item.cat_name,
              label: item.cat_name,
              cat_id: item.cat_id, // cat
              nestedOptions: [
                ...item.subcat.map((subItem) => {
                  {
                    console.log(subItem, "subItem");
                  }
                  return {
                    value: subItem,
                    label: subItem,
                    cat_id: item.cat_id,
                  }; //cat
                }),
                {
                  label: "Add Office Sub Expense",
                  value: "Add Office Sub Expense",
                  cat_id: item.cat_id, //cat
                  isSpecial: true,
                },
              ],
            })),

            // handling Data Dynamically
            // {
            //   value: "elctricity",
            //   label: "Electricity",
            //   nestedOptions: [
            //     { value: "aaa", label: "aaaa" },
            //     { value: "bbb", label: "bbb" },
            //     {
            //       label: "Add Office Sub Expense",
            //       value: "Add Office Sub Expense",
            //       isSpecial: true,
            //     },
            //   ],
            // },
            // {
            //   value: "vehicle",
            //   label: "vehicle",
            //   nestedOptions: [
            //     { value: "petrol", label: "petrol" },
            //     { value: "vehicle maintanance", label: "vehicle maintanance" },
            //     {
            //       label: "Add Office Sub Expense",
            //       value: "Add Office Sub Expense",
            //       isSpecial: true,
            //     },
            //   ],
            // },
            {
              label: "Add Office Expense",
              value: "Add Office Expense",
              isSpecial: true,
            },
          ],
        },
        // ⚠
        {
          name: "clientExpenses",
          label: "Client Reference Invoice",
          type: "text",
          placeholder: "Enetr the Invoice Number",
        },
        {
          name: "ClientExpensesCategory",
          label: "Client Expenses Category",
          type: "dropdown",
          options: [
            { value: "select", label: "select" },
            ...allCategory_Client?.map((item) => ({
              value: item.cat_name,
              label: item.cat_name,
              cat_id: item.cat_id, // cat
              nestedOptions: [
                ...item.subcat.map((subItem) => {
                  {
                    console.log(subItem, "subItem");
                  }
                  return {
                    value: subItem,
                    label: subItem,
                    cat_id: item.cat_id,
                  }; //cat
                }),
                {
                  label: "Add Client Sub Expense +",
                  value: "Add Client Sub Expense",
                  isSpecial: true,
                },
              ],
            })),
            // {
            //   value: "lunch",
            //   label: "lunch",
            //   nestedOptions: [
            //     { value: "aaa", label: "aaaa" },
            //     { value: "bbb", label: "bbba" },
            //     {
            //       label: "Add Client Sub Expense ",
            //       value: "Add Sub Client Expense",
            //       isSpecial: true,
            //     },
            //   ],
            // },
            // {
            //   value: "travel",
            //   label: "travel",
            //   nestedOptions: [
            //     { value: "cccc", label: "cccca" },
            //     { value: "ddd", label: "ddda" },
            //     {
            //       label: "Add Client Sub Expense",
            //       value: "Add Sub Client Expense",
            //       isSpecial: true,
            //     },
            //   ],
            // },
            {
              label: "Add Client Expense",
              value: "Add Client Expense",
              isSpecial: true,
            },
          ],
        },
      ],
    },
    {
      heading: "Invoice Status",
      fields: [
        {
          name: "pay_mode",
          label: "Payment Mode",
          type: "dropdown",
          options: [
            { value: "select", label: "select" },
            { value: "cash", label: "Cash" },
            { value: "credit", label: "Credit" },
          ],
        },
        {
          name: "cash",
          label: "Cash Transaction",
          type: "dropdown",
          options: [
            { value: "select", label: "select" },
            {
              value: "Petty cash",
              label: "Petty cash",
            },
            {
              value: "Credit Card",
              label: "Credit Card",
            },
            {
              value: "Null",
              label: "Null",
            },
            ...allCashTn?.map((item) => ({
              value: item.cash_type,
              label: item.cash_type,
              cash_id: item.id,
            })),

            {
              value: "Add New Payment",
              label: "Add New Payment ",
              isSpecial: true,
            },
          ],
        },
        {
          name: "credit",
          label: "Due Date",
          type: "date",
          // type: "dropdown",
          // options: [
          //   { value: "2 days credit period", label: "2 days credit period" },
          //   { value: "7 days credit period", label: "7 days credit period" },
          //   { value: "10 days credit period", label: "10 days credit period" },
          //   { value: "15 days credit period", label: "15 days credit period" },
          //   { value: "20 days credit period", label: "20 days credit period" },
          //   { value: "30 days credit period", label: "30 days credit period" },
          // ],
        },
      ],
    },
    {
      heading: "Additional information",
      fields: [
        {
          name: "emp_id",
          label: "Emp ID",
          type: "dropdown",
          options: [
            { value: "", label: "Select" },
            { value: "Shoeb", label: "Shoeb" },
            { value: "Suleman", label: "Suleman" },
            { value: "Sanjay", label: "Sanjay" },
            { value: "Hamza", label: "Hamza" },
            // {value:"Add Emoloyee" , label:"Add Emoloyee", isSpecial:true}
          ],
        },
        {
          name: "Pay_priority",
          label: "Payment Priority",
          type: "dropdown",
          options: [
            { value: "", label: "Select" },
            { value: "Urgent", label: "Urgent" },
            { value: "High", label: "High" },
            { value: "Medium", label: "Medium" },
            { value: "Standard", label: "Standard" },
          ],
        },
        { name: "notes", label: "Notes", type: "text" },
      ],
    },
  ];

  const handleSubmit = async (values, { resetForm, setSubmitting }) => {
    console.log(values, "Expenses_Values");

    try {
      const combinedData = {
        ...values,
        ...formData,
      };
      const response = await axios.post(
        // "https://1sdapp.com/api/expensesDetails", // Change The API URL #if required
        "https://api.1sdapp.com/api/expensesDetails",
        combinedData
      );
      toast.success(
        `YOUR EXPENSES RECORD HAS BEEN SUCESSFULLY SAVED - REFERENCE NUMBER FOR YOUR RECORD IS ${String.fromCharCode(
          160
        ).repeat(0)} : ${response.data.data.uniq_id} `
      );

      if (closeExp) {
        toast.warn("Save & close btn clicked");
        Navigate(-1);
      } else {
        setTimeout(() => {
          window.location.reload();
        }, 4000);
      }
      // resetForm();
      // setFormData((prevData) => {
      //   let clear = {};
      //   for (let key in prevData) {
      //     clear[key] = "";
      //   }
      //   return clear;
      // });

      console.log(response, "response!", response.data, "response.data");
    } catch (error) {
      console.log(error, "error");
      toast.error("Internal Server Error");
    } finally {
      setSubmitting(false);
    }
  };

  const handleSaveAndNew = () => {
    toast.warn("Save & New btn clicked");
    handleSubmit();
  };

  const handleSaveAndClose = () => {
    handleSubmit();
    toast.warn("Save & close btn clicked");

    // setTimeout(() => Navigate("/dglory"), 700);
  };

  const handleSaveAndPay = () => {
    toast.warn("Save & Pay btn clicked");
  };

  console.log(formData, "formDATAA");
  console.log(allCategory, "All Catz");
  console.log(allCategory_Client, "All Client Catz");
  console.log(catName, "catNamex");
  return (
    <div id="Expenses-Section">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          EXPENSES
        </div>
        <div className="flex-1 flex gap-5 justify-end">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem] " />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="formContainer mb-16">
        <Formik
          validationSchema={ExpensesSchema}
          initialValues={initialValues}
          onSubmit={handleSubmit}
          // onSubmit={handleSaveAndNew}
        >
          <Form id="formikForm">
            {ExpensesFields.map((item, index) => (
              <React.Fragment key={index}>
                <h2 className="col-span-4 mt-3 text-[1.2rem] font-semibold text-[#fff] underline uppercase ">
                  {item.heading}
                </h2>
                {item.fields.map((input, index) => (
                  <>
                    <>
                      {input.type === "dropdown" &&
                        input.name !== "cash" &&
                        input.name !== "credit" &&
                        input.name !== "pay_mode" &&
                        input.name !== "officeExpense" &&
                        input.name !== "clientExpenses" &&
                        input.name !== "ClientExpensesCategory" && (
                          <DropDown
                            name={input.name}
                            options={input.options}
                            label={input.label}
                            onChange={handleDropDown}
                          />
                        )}

                      {input.type === "dropdown" &&
                        input.name === "pay_mode" && (
                          <DropDown
                            name={input.name}
                            options={input.options}
                            label={input.label}
                            onChange={handleDropDown} // receiving the arguments from Child
                          />
                        )}
                      {input.type === "textarea" && (
                        <Textarea
                          name={input.name}
                          label={input.label}
                          value={formData[input.name]}
                          onChange={(e) =>
                            handleInputChange(e.target.name, e.target.value)
                          }
                        />
                      )}
                      {input.type === "dropdown" &&
                        input.name !== "pay_mode" &&
                        selectedPaymentMode === input.name && (
                          <DropDown
                            name={input.name}
                            options={input.options}
                            label={input.label}
                            onChange={handleDropDown}
                          />
                        )}
                    </>

                    {/* expenses */}

                    {input.type === "dropdown" &&
                      (costCenter === input.name ||
                        (costCenter === "clientExpenses" &&
                          input.name === "ClientExpensesCategory")) && (
                        <>
                          {console.log(input.name, "ExpensesCC$")}
                          <DropDown
                            name={input.name}
                            options={input.options}
                            label={input.label}
                            onChange={handleDropDown}
                          />
                        </>
                      )}

                    {input.type === "text" && costCenter === input.name && (
                      <FormikFieldExp
                        key={index}
                        field={input}
                        // value={formData[input.name]}
                        value={formData[input.name] || ""}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}

                    {input.type === "text" &&
                      input.name !== "clientExpenses" && (
                        <FormikFieldExp
                          key={index}
                          field={input}
                          // value={formData[input.name]}
                          value={formData[input.name] || ""}
                          onChange={(e) =>
                            handleInputChange(e.target.name, e.target.value)
                          }
                        />
                      )}
                    {input.type === "date" && input.name !== "credit" && (
                      <FormikField key={index} field={input} />
                    )}
                    {input.type === "date" &&
                      input.name !== "pay_mode" &&
                      selectedPaymentMode === input.name && (
                        <FormikField key={index} field={input} />
                      )}
                  </>
                ))}
              </React.Fragment>
            ))}
            <p
            // className="Neom px-4 m-4 bg-orange-700 rounded-md h-1/2
            //   tracking-wide font-bold "
            // type=""
            >
              {/* SUBMIT */}
            </p>
            <button
              className={` px-4 m-4 bg-white hover:bg-[#4b5563] ease-linear duration-300 hover:text-white transis border-2 rounded-md h-1/2
                tracking-wide font-bold justify-self-center w-[90%] ${
                  disable
                    ? "opacity-30 cursor-not-allowed hover:bg-white hover:text-black "
                    : ""
                }`}
              type="submit"
              // onClick={() => handleSaveAndNew()}
              // onClick={() => handleSubmit()}
              disabled={disable}
            >
              SAVE & NEW
            </button>
            <button
              className={` px-4 m-4 bg-white hover:bg-[#4b5563] ease-linear duration-300 hover:text-white transis border-2 rounded-md h-1/2
                tracking-wide font-bold justify-self-center w-[90%] ${
                  disable
                    ? "opacity-30 cursor-not-allowed hover:bg-white hover:text-black "
                    : ""
                }`}
              type="submit"
              onClick={() => setCloseExp(true)}
              disabled={disable}
            >
              SAVE & CLOSE
            </button>
            <button
              className=" px-4 m-4 bg-white hover:bg-[#4b5563] ease-linear
               duration-300 hover:text-white transis border-2 rounded-md h-1/2
              tracking-wide font-bold justify-self-center w-[90%]"
              type="button"
              onClick={() => handleSaveAndPay()}
            >
              SAVE & PAY
            </button>
          </Form>
        </Formik>
      </div>
      {displayModal && (
        <NewInput
          onClose={() => setDisplayModal(false)}
          isOpen={displayModal}
          addOfficeExp1={addOfficeExp1}
          setAddOfficeExp1={setAddOfficeExp1}
          addOffice_SubExp={addOffice_SubExp}
          setAddOffice_SubExp={setAddOffice_SubExp}
          addClientExp1={addClientExp1}
          setAddClientExp1={setAddClientExp1}
          addClient_SubExp={addClient_SubExp}
          setAddClient_SubExp={setAddClient_SubExp}
          catName={catName}
          reload={reload}
          catId={catId}
          catId_Client={catId_Client}
          addCashTn={addCashTn}
          setaddCashTn={setaddCashTn}
        />
      )}
    </div>
  );
};

export default Expenses;
