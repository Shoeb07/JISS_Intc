<>
{input.type === "dropdown" &&
input.name !== "cash" &&  input.name !== "credit" && (
  <DropDown
    name={input.name}
    options={input.options}
    label={input.label}
    onChange={(e) =>
      handleDropDown(input.name, e.target.value)
    }
  />
)}
{/* <DropDown
name={input.name}
options={input.options}
label={input.label}
onChange={(e) =>
  handleDropDown(input.name, e.target.value)
}
/>
{console.log(selectedPaymentMode, input,"togglr")}
{input.name === "cash" &&
selectedPaymentMode === "cash" && (
  <DropDown
    name={input.name}
    options={input.options}
    label={input.label}
  />
)}
{input.name === "credit" &&
selectedPaymentMode === "credit" && (
  <DropDown
    name={input.name}
    options={input.options}
    label={input.label}
  />
)} */}

{input.type === "dropdown" &&
input.name === "paymentmode" && (
  <DropDown
    name={input.name}
    options={input.options}
    label={input.label}
    onChange={(e) =>
      handleDropDown(input.name, e.target.value)
    }
  />
)}

{input.type === "dropdown" &&
input.name !== "paymentmode" &&
selectedPaymentMode === input.name && (
  <DropDown
    name={input.name}
    options={input.options}
    label={input.label}
  />
)}
</>