import React, { useEffect, useState } from "react";
import "./DropDown.css";

const DropDown = ({ name, options, label, onChange }) => {
  const [nestedOptions, setNestedOptions] = useState([]);

  const handleMainDropDown = (e) => {
    const selectedValue = e.target.value;

    const selectedOption = options.find(
      (option) => option.value === selectedValue
    );

    setNestedOptions(selectedOption?.nestedOptions || []);

    onChange(name, selectedValue, selectedOption?.isSpecial);
  };

  const handleNestedDropDown = (e) => {
    const updatedName = name.replace(/cat(\d+)/, (match, p1) => {
      const newNumber = p1 === "1" ? "2" : p1;
      return `cat${newNumber}`;
    });

    // onChange(`nested-${name}`, e.target.value);
    onChange(updatedName, e.target.value);
    // console.log(`nested-${name}`, e.target.value, "nesteddd valueee");
  };

  // console.log(nestedOptions, "DropDown.jsx");
  return (
    <div className="flex flex-col  m-2">
      <label className="text-white" htmlFor={name}>
        {label}
      </label>

      <select
        className=" inputField border-2 border-black outline-none rounded-md  "
        name={name}
        // onChange={onChange}
        onChange={handleMainDropDown}
      >
        {options.map((item, idx) => (
          <option key={idx} value={item.value}>
            <span>
              {item.label}
              {item.isSpecial && (
                <span>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; +</span>
              )}
            </span>
          </option>
        ))}
      </select>

      {nestedOptions.length > 0 && (
        <select
          className=" inputField border-2 border-black outline-none rounded-md"
          name={`nested-${name}`}
          onChange={handleNestedDropDown}
        >
          <option value={""}>Select..</option>
          {nestedOptions.map((item, idx) => (
            <option key={idx} value={item.value}>
              {item.label}
            </option>
          ))}
        </select>
      )}
    </div>
  );
};

export default DropDown;
