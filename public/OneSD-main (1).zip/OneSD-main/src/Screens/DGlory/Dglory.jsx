// import React from "react";
// import "./Dglory.css";
// import { MdAddCircleOutline } from "react-icons/md";
// import { useNavigate } from "react-router-dom";

// const Dglory = () => {
//   const Navigate = useNavigate();

//   return (
//     <div className="Dglory-Main">
//       <div className="title text-center text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl ">
//         DGLORY
//       </div>
//       <div className="content">
//         <div className="cards" onClick={() => Navigate("/dglory/registration")}>
//           <div className="outer">
//             <h2 className="text-xl font-semibold text-white">Company Registration </h2>
//             <MdAddCircleOutline className="text-xl text-white" />
//           </div>
//         </div>
//         <div className="cards" onClick={() => Navigate("/dglory/vendors")}>
//           <div className="outer">
//             <h2 className="text-xl font-semibold text-white">Vendor Registration</h2>
//             <MdAddCircleOutline className="text-xl text-white" />
//           </div>
//         </div>
//         <div className="cards" onClick={() => Navigate("/clientReg")}>
//           <div className="outer">
//             <h2 className="text-xl font-semibold text-white">Client Registration</h2>
//             <MdAddCircleOutline className="text-xl text-white" />
//           </div>
//         </div>
//         <div className="cards" onClick={() => Navigate("/dglory/expenses")}>
//           <div className="outer">
//             <h2 className="text-xl font-semibold text-white">Expenses</h2>
//             <MdAddCircleOutline className="text-xl text-white" />
//           </div>
//         </div>
      
//         <div className="cards" onClick={() => Navigate("")}>
//           <div className="outer">
//             <h2 className="text-xl text-white">Custom Field</h2>
//             <MdAddCircleOutline className="text-xl text-white" />
//           </div>
//         </div>
//         <div className="cards" onClick={() => Navigate("")}>
//           <div className="outer">
//             <h2 className="text-xl text-white">Custom Field</h2>
//             <MdAddCircleOutline className="text-xl text-white" />
//           </div>{" "}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Dglory;
