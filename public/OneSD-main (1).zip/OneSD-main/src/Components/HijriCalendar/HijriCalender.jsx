import React, { useState } from "react";
import DatePicker from "react-multi-date-picker";

import { Calendar } from "react-multi-date-picker";
import arabic from "react-date-object/calendars/arabic";
import arabic_ar from "react-date-object/locales/arabic_ar";

const HijriCalender = ({ field, onChange }) => {
  const [selectedHijriDate, setSelectedHijriDate] = useState(null);

  const [getDate, setGetDate] = useState();

  const handleDateChange = (date) => {
    setSelectedHijriDate(date);
    const formattedDate = date ? date.format("YYYY/MM/DD") : "";
    onChange(field.name, formattedDate);
    setGetDate(formattedDate);
  };

  // console.log(selectedHijriDate?.toString(), "Date Picked", field.name);

  return (
    <div className=" flex-col flex gap-2">
      <label className="text-white" htmlFor={field?.name}>
        {field?.label}
      </label>
      <div className="inputField flex items-center overflow-hidden w-[10px]">
        <DatePicker
          style={{
            border: "none",
            outline: "none",
            width:"10px",
            backgroundImage: `url('https://tse3.mm.bing.net/th?id=OIP.uWH0kRBZknmmhgoY0_A1gwAAAA&pid=Api&P=0&h=180')`, // Replace with your icon URL
            backgroundRepeat: "no-repeat",
            backgroundPosition: "left center", // Adjust the icon position
            backgroundSize: "20px 20px",
            cursor:"pointer",
            marginRight:'35px'
          }}
          selected={selectedHijriDate}
          onChange={handleDateChange}
          dateFormat="yyyy/MM/dd"
          calendar={arabic}
          locale={arabic_ar}
        />
        <p>{getDate}</p>
      </div>
    </div>
  );
};

export default HijriCalender;
