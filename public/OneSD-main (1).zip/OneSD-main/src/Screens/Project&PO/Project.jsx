import React, { useEffect, useState } from "react";
import "./Projects.css";
import { PiPlaceholder } from "react-icons/pi";
import { Form, Formik } from "formik";
import FormikField from "../../Components/Formik/FormikField";
import DropDown from "../../Components/DropDown/DropDown";
import * as Yup from "yup";
import { toast } from "react-toastify";
import axios from "axios";
import FormikFieldExp from "../../Components/Formik/FormikFieldExp";
import { MdOutlineKeyboardBackspace } from "react-icons/md";
import { useNavigate } from "react-router-dom";
import DataList from "../../Components/DropDown/DataList";
import Textarea from "../../Components/Textarea/Textarea";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";

const Project = () => {
  const [formData, setFormData] = useState({});

  const [companyList, setCompanyList] = useState([]);
  const [clientList, setClientList] = useState([]);

  const Navigate = useNavigate();

  const handleInputChange = (name, value) => {
    console.log(name, value, "handlechnaGWE");
    setFormData({ ...formData, [name]: value });
  };

  const handleDropDown = (name, value) => {
    console.log(name, value, "handle Drop");
    handleInputChange(name, value);

    if (name === "Business_name" && value === "Add a New Business") {
      console.log("open businessssss TAG");
      Navigate("/dglory/Companies/registration");
    }
    if (name === "Client_name" && value === "Add Client") {
      console.log("open businessssss TAG");
      Navigate("/dglory/clients/registration");
    }
  };

  const ProjectSchema = Yup.object().shape({
    // Project Value : Yup.string().required('This is required');
  });

  const initialValues = {
    // Project Value: "",
  };
  console.log(formData);
  const ProjectDetails = [
    {
      heading: "Project Details",
      fields: [
        {
          name: "Business_name",
          label: "Business Name",
          placeholder: "Business Name",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            ...companyList,
            { value: "DGLORY", label: "DGLORY" },
            { value: "BAKSH", label: "BAKSH" },
            { value: "WAM", label: "WAM" },
            { value: "AL MUKAAB", label: "AL MUKAAB" },
            { value: "JISS", label: "JISS" },
            {
              value: "Add a New Business",
              label: "Add a New Business ",
              isSpecial: true,
            },
          ],
        },
        {
          name: "Proposal_No",
          label: "Proposal No",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            { value: "PO1", label: "PO1" },
            { value: "PO1", label: "PO2" },
            { value: "PO2", label: "PO3" },
          ],
        },
        {
          name: "Date",
          label: "Open Date",
          placeholder: "Date",
          type: "date",
        },
        {
          name: "CloseDate",
          label: "Close Date",
          placeholder: "Date",
          type: "date",
        },
        {
          name: "Client_name",
          label: "Client",
          placeholder: "Client",
          type: "dropdown",
          options: [
            { value: "", label: "select" },
            ...clientList,
            { value: "Binladen Group", label: "Binladen Group" },
            { value: "Khorasani Group", label: "Khorasani Group" },
            {
              value: "Add Client",
              label: "Add Client ",
              isSpecial: true,
            },
          ],
        },
        {
          name: "City",
          label: "City",
          placeholder: "City",
          type: "text",
        },
        {
          name: "Country",
          label: "Country",
          placeholder: "Country",
          type: "dropdown",
          options: [
            { label: "select", value: "" },
            { label: "KSA", value: "KSA" },
            { label: "PAK", value: "PAK" },
            { label: "IND", value: "IND" },
          ],
        },
        {
          name: "Project_title",
          label: "Project Title",
          placeholder: "Project Title",
          type: "text",
        },
        {
          name: "Project_type1",
          label: "Project Type",
          placeholder: "Project Type",
          type: "dropdown",
          options: [
            { label: "select", value: "" },
            { label: "Option 1", value: "Option 1" },
            { label: "Option 2", value: "Option 2" },
            {
              value: "Add Project Type",
              label: "Add Project Type",
              isSpecial: true,
            },
          ],
        },
        {
          name: "Project_desc",
          label: "Project Description",
          placeholder: "Project Description",
          type: "desc",
        },
        {
          name: "Project_value",
          label: "Project Value",
          placeholder: "Project Value",
          type: "text",
        },
        {
          name: "Vat_per",
          label: "VAT %",
          placeholder: "VAT",
          type: "text",
          // type: "dropdown",
          // options: [
          //   { value: "0%", label: "0%" },
          //   { value: "5%", label: "5%" },
          //   { value: "10%", label: "10%" },
          //   { value: "15%", label: "15%" },
          // ],
        },
        {
          name: "Total",
          label: "Total",
          placeholder: "Total",
          type: "text",
        },
        {
          name: "Employee_Id",
          label: "Employee ID",
          placeholder: "Employee ID",
          type: "dropdown",
          options: [
            { value: "", label: "Select" },
            { value: "Shoeb", label: "Shoeb" },
            { value: "Suleman", label: "Suleman" },
            { value: "Sanjay", label: "Sanjay" },
            { value: "Hamza", label: "Hamza" },
            // {value:"Add Emoloyee" , label:"Add Emoloyee", isSpecial:true}
          ],
        },
        {
          name: "Project_Manager",
          label: "PM",
          placeholder: "PM",
          type: "dropdown",
          options: [
            { value: "", label: "Select" },
            { value: "Shoeb", label: "Shoeb" },
            { value: "Suleman", label: "Suleman" },
            { value: "Sanjay", label: "Sanjay" },
            { value: "Hamza", label: "Hamza" },
            // {value:"Add Emoloyee" , label:"Add Emoloyee", isSpecial:true}
          ],
        },
      ],
    },
  ];

  useEffect(() => {
    const calculateVAT = () => {
      const amountBeforeVAT = parseFloat(formData["Project_value"]) || 0;
      const vatPercentage = parseFloat(formData["Vat_per"]) || 0;
      const vatAmount = (amountBeforeVAT * vatPercentage) / 100;
      const TotalAmount = amountBeforeVAT + vatAmount;
      setFormData((prevData) => ({
        ...prevData,
        Total: TotalAmount.toFixed(2),
      }));
      console.log(amountBeforeVAT, "amountBeforeVAT ");
      console.log(vatPercentage, "vatttt %");
      console.log(vatAmount, "vatAmount");
      console.log(TotalAmount, "totalAmountWithVAT");
    };
    calculateVAT();
  }, [formData["Project_value"], formData["Vat_per"]]);

  const handleSubmit = async (values, { setSubmitting }) => {
    console.log(values, "project_Values");
    let clubbedData = {
      ...values,
      ...formData,
    };
    console.log(clubbedData, "FORMDATA!");
    try {
      const response = await axios.post(
        // "https://api.1sdapp.com/projectDetails",
        "https://api.1sdapp.com/api/projectDetails",
        // values
        clubbedData
      );
      toast.success(
        `PROJECT SUBMITTED SUCCESSFULLY - UNIQUE ID FOR THE PROJECT IS ${
          response.data.data.uniq_id || ""
        }`
      );
      console.log(response, "response!", response.data, "response.data");
    } catch (error) {
      console.log(error, "error");
      toast.error("Internal Server Error");
    } finally {
      setSubmitting(false);
    }
  };

  useEffect(() => {
    const getCompanies = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getOurCompanyDetails"
        );
        const data = response.data.data;

        const options = data
          .filter(
            (company) =>
              company.ShortName_EN && company.ShortName_EN.trim() !== ""
          )
          .map((company) => ({
            value: company.ShortName_EN,
            label: company.ShortName_EN,
          }));

        setCompanyList(options);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getCompanies();
  }, []);

  useEffect(() => {
    const getClients = async () => {
      try {
        const response = await axios.get(
          "https://api.1sdapp.com/api/getAllClientDetails"
        );
        const data = response.data.data;

        const options = data
          .filter(
            (client) => client.ShortName_EN && client.ShortName_EN.trim() !== ""
          )
          .map((client) => ({
            value: client.ShortName_EN,
            label: client.ShortName_EN,
          }));

        setClientList(options);
      } catch (err) {
        console.log(err, "vendors Error");
      }
    };
    getClients();
  }, []);

  console.log(formData, "FORMDATA!");

  return (
    <div id="Project-Section">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          Project
        </div>
        <div className="flex-1 flex gap-5 justify-end">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem] " />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="formContainer mb-16">
        <Formik
          validationSchema={ProjectSchema}
          initialValues={initialValues}
          onSubmit={handleSubmit}
        >
          <Form id="formikForm">
            {ProjectDetails.map((item, index) => (
              <React.Fragment key={index}>
                <h2 className="col-span-4 m-4 text-[1.2rem] font-semibold text-[#fff] underline uppercase ">
                  {item.heading}
                </h2>
                {item.fields.map((input, idx) => (
                  <>
                    {input.type === "dropdown" && (
                      <DropDown
                        key={idx}
                        name={input.name}
                        label={input.label}
                        options={input.options}
                        onChange={handleDropDown}
                      />
                    )}
                    {/* {input.type === "data" && (
                      <DataList
                        key={idx}
                        name={input.name}
                        label={input.label}
                        options={input.options}
                        // value={formData["Vat_per"]}
                        onChange={handleDropDown}
                      />
                    )} */}
                    {input.type === "text" && (
                      <FormikFieldExp
                        key={index}
                        field={input}
                        value={formData[input.name]}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                    {input.type === "desc" && (
                      <Textarea
                        name={input.name}
                        label={input.label}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                    {input.type === "date" && (
                      <FormikFieldExp
                        key={index}
                        field={input}
                        // value={formData[input.name]}
                        // onChange={(e) =>
                        //   handleInputChange(e.target.name, e.target.value)
                        // }
                        value={formData[input.name]}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                  </>
                ))}
              </React.Fragment>
            ))}
            {/* <button
              className=" px-8 m-7 bg-white hover:bg-[#4b5563] ease-linear
                          duration-300 hover:text-white transis border-2 rounded-md h-1/2
                         tracking-wide font-bold justify-self-center"
              type="button"
            >
              Expenses
            </button> */}
            <button
              className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                          duration-300 hover:text-white transis border-2 rounded-md h-1/2
                         tracking-wide font-bold justify-self-center"
              type="submit"
            >
              Save Project
            </button>
          </Form>
        </Formik>
      </div>
    </div>
  );
};

export default Project;
