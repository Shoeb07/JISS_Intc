import { ErrorMessage, Field } from "formik";
import React from "react";
import "./FormikField.css";

const FormikFieldExp = ({ field, value, onChange }) => {
  // console.log(field, "EXPP");
  return (
    <div className=" flex flex-col m-2">
      <label className="text-white" htmlFor={field?.name}>
        {field?.label}
      </label>

      <Field
        name={field?.name}
        type={field?.type}
        readOnly={field?.readOnly}
        style={field?.name === "Currency" ? { width: "90px" } : null}
        className=" inputField border-2 border-black outline-none rounded-md"
        value={value}
        onChange={onChange}
        // placeholder={field.placeholder}
      />

<ErrorMessage name={field?.name} component="div"
       className="error absolute bottom-[-17px] text-red-500 rounded-[3px] bg-gray-900 text-[0.8rem] px-2 font-semibold italic " />
    </div>
  );
};

export default FormikFieldExp;
