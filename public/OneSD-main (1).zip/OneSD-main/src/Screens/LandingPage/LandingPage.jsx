import React from "react";
import "./Landing.css";
import { useNavigate } from "react-router-dom";

const LandingPage = () => {
  const navigate = useNavigate();

  return (
    <div className="content">
      <div className="title">
        <h1>1SD</h1>
      </div>
      <div className="subtitle">
        <div className="card" onClick={() => navigate("/dglory")}>
          <div className="circle">
            <h3>DGLORY</h3>
          </div>
        </div>
        <div className="card" onClick={() => navigate("/wam")}>
          <div className="circle">
            <h3>WAM</h3>
          </div>
        </div>
        <div className="card" onClick={() => navigate("/baksh")}>
          <div className="circle">
            <h3>BAKSH</h3>
          </div>
        </div>
        <div className="card" onClick={() => navigate("/m2")}>
          <div className="circle">
            <h3>M2 / AL MUKAAB</h3>
          </div>
        </div>
        <div className="card" onClick={() => navigate("/jiss")}>
          <div className="circle">
            <h3>JISS</h3>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
