import React, { useState } from "react";
import "./PurchaseOrder.css";
import { useNavigate } from "react-router-dom";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";
import { Form, Formik } from "formik";
import DropDown from "../../Components/DropDown/DropDown";
import FormikFieldExp from "../../Components/Formik/FormikFieldExp";
import Textarea from "../../Components/Textarea/Textarea";
import * as Yup from "yup";

const PurchaseOrder = () => {
  const [formData, setFormData] = useState({});

  const Navigate = useNavigate();

  const initialValues = {
    Business: "",
  };

  const validationSchema = Yup.object().shape({
    // Business: Yup.string.required("This is a required Filld"),
  });

  const handleInputChange = (name, value) => {
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleDropDown = () =>{




  }

  const handleSubmit = async () => {};

  const purchaseOrderDetails = [
    {
      heading: "Basic Information",
      fields: [
        { name: "search", type: "text", label: "Search" },
        {
          name: "PO Reference Number",
          label: "PO Reference Number",
          type: "text",
          readOnly: true,
        },
        {
            name: "Business",
            label: "Business",
            type: "dropdown",
            options:[
                {value:"", label:"option1"},
                {value:"", label:"option2"},
            ]
        },
        {
            name: "Branch",
            label: "Branch",
            type: "dropdown",
            options:[
                {value:"", label:"option1"},
                {value:"", label:"option2"},
            ]
        },
        {
            name:"Quote Number",
            label:"Quote Number",
            type:"text",
        },
        {
            name:"Quote Dated",
            label:"Quote Dated",
            type:"date",
        },
        {
            name:"Description",
            label:"Description",
            type:"textarea",
        },
      ],
    },
    {
      heading: "Client Information",
      fields: [
        {
          name: "Client",
          label: "Client",
          type: "text",
        },
        {
          name: "PO Number",
          label: "PO Number",
          type: "text",
        },
        {
          name: "Received On",
          label: "Received On",
          type: "text",
        },
        {
          name: "Received Via",
          label: "Received Via",
          type: "text",
        },
        {
          name: "PO Status",
          label: "PO Status",
          type: "text",
        },
        {
          name: "Amount",
          label: "Amount",
          type: "text",
        },
        {
          name: "VAT Amount",
          label: "VAT Amount",
          type: "text",
        },
        {
          name: "Total Amount",
          label: "Total Amount",
          type: "text",
        },
        {
          name: "Remarks",
          label: "Remarks",
          type: "text",
        },
        {
          name: "Attach PO",
          label: "Attach PO",
          type: "file",
        },
      ],
    },
    {
      heading: "Other Information",
     fields:[
        {
            name:"Estimated Budget",
            label:"Estimated Budget",
            type:"text",
        },
        {
            name:"Estimated VAT",
            label:"Estimated VAT",
            type:"text",
        },
        {
            name:"Estimated Total Budget",
            label:"Estimated Total Budget",
            type:"text",
        },
        {
            name:"Remarks",
            label:"Remarks",
            type:"textarea",
        },
     ]
    },
  ];

  return (
    <div id="PurchaseOrder-Section">
      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          Purchase Order
        </div>
        <div className="flex-1 flex gap-5 justify-end">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] w-fit h-fit flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem] " />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="formContainer mb-16">
        <Formik
          validationSchema={validationSchema}
          initialValues={initialValues}
          onSubmit={handleSubmit}
        >
          <Form id="formikForm">
            {purchaseOrderDetails.map((item, index) => (
              <React.Fragment key={index}>
                <h2 className="col-span-4 m-4 ml-0 text-[1.2rem] font-semibold text-[#fff] underline uppercase ">
                  {item.heading}
                </h2>
                {item.fields.map((input, idx) => (
                  <>
                    {input.type === "dropdown" && (
                      <DropDown
                        key={idx}
                        name={input.name}
                        label={input.label}
                        options={input.options}
                        onChange={handleDropDown}
                      />
                    )}

                    {input.type === "text" && (
                      <FormikFieldExp
                        key={idx}
                        field={input}
                        value={formData[input.name]}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                    {input.type === "textarea" && (
                      <Textarea
                        name={input.name}
                        label={input.label}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                    {input.type === "date" && (
                      <FormikFieldExp
                        key={idx}
                        field={input}
                        value={formData[input.name]}
                        onChange={(e) =>
                          handleInputChange(e.target.name, e.target.value)
                        }
                      />
                    )}
                  </>
                ))}
              </React.Fragment>
            ))}

            
            <button
              className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                        duration-300 hover:text-white transis border-2 rounded-md h-1/2
                       tracking-wide font-bold justify-self-center w-[90%]"
              type="submit"
            >
              SAVE
            </button>
            <button
              className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                        duration-300 hover:text-white transis border-2 rounded-md h-1/2
                       tracking-wide font-bold justify-self-center w-[90%]"
              type="submit"
            >
              SAVE & NEW
            </button>
            <button
              className=" px-4 m-7 bg-white hover:bg-[#4b5563] ease-linear
                        duration-300 hover:text-white transis border-2 rounded-md h-1/2
                       tracking-wide font-bold justify-self-center w-[90%]"
              type="submit"
            >
              SAVE & CLOSE
            </button>
          </Form>
        </Formik>
      </div>
    </div>
  );
};

export default PurchaseOrder;
