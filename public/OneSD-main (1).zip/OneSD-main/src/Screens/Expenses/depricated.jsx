 // const ExpensesFields = [
  //   {
  //     name: "client_name_exp",
  //     label: "Client Name EN",
  //     placeholder: "Client Name EN",
  //     type: "text",
  //   },
  //   {
  //     name: "rep_name_exp",
  //     label: "REP Name EN",
  //     placeholder: "REP Name EN",
  //     type: "text",
  //   },
  //   {
  //     name: "Ven_name_exp",
  //     label: "Vendor Name EN",
  //     placeholder: "Vendor Name EN",
  //     type: "text",
  //   },
  //   {
  //     name: "Desc_exp",
  //     label: "Description EN",
  //     placeholder: "Description EN",
  //     type: "text",
  //   },
  //   {
  //     name: "Invoice_dt_exp",
  //     label: "Invoice Date",
  //     type: "date",
  //   },
  //   {
  //     name: "Invoice_no_exp",
  //     label: "Invoice No",
  //     type: "tel",
  //   },
  //   {
  //     name: "pay_stat_exp",
  //     label: "Payment Status EN",
  //     placeholder: "Payment Status EN",
  //     type: "text",
  //   },
  //   {
  //     name: "due_amt_exp",
  //     label: "Due Amt EN",
  //     placeholder: "Due Amt EN",
  //     type: "text",
  //   },
  //   {
  //     name: "amt_bef_tax_exp",
  //     label: "Amt Before Tax EN",
  //     placeholder: "Amt Before Tax EN",
  //     type: "text",
  //   },
  //   {
  //     name: "disc_exp",
  //     label: "Discount EN",
  //     placeholder: "Discount EN",
  //     type: "text",
  //   },
  //   {
  //     name: "vat15p_exp%",
  //     label: "VAT 15% EN",
  //     placeholder: "VAT 15% EN",
  //     type: "text",
  //   },
  //   {
  //     name: "amt_After_Tax_&_Disc",
  //     label: "Amt After Tax & Disc. EN",
  //     placeholder: "Amt After Tax & Disc. EN",
  //     type: "text",
  //   },
  //   {
  //     name: "paid_amt_exp",
  //     label: "Paid Amt EN",
  //     placeholder: "Paid Amt EN",
  //     type: "text",
  //   },
  //   {
  //     name: "pay_mode_exp",
  //     label: "Payment Mode EN",
  //     placeholder: "Payment Mode EN",
  //     type: "text",
  //   },
  //   {
  //     name: "pay_dt_exp",
  //     label: "Payment Date EN",
  //     placeholder: "Payment Date EN",
  //     type: "date",
  //   },
  //   {
  //     name: "mon_tot_exp",
  //     label: "Monthly Total EN",
  //     placeholder: "Monthly Total EN",
  //     type: "text",
  //   },
  //   {
  //     name: "bank_ac_exp",
  //     label: "Bank A/C Details EN",
  //     placeholder: "Bank A/C Details EN",
  //     type: "text",
  //   },
  //   {
  //     name: "remrk_exp",
  //     label: "Remarks EN",
  //     placeholder: "Remarks EN",
  //     type: "text",
  //   },
  //   {
  //     name: "benef_exp",
  //     label: "Beneficiary EN",
  //     placeholder: "Beneficiary EN",
  //     type: "text",
  //   },
  //   {
  //     name: "rem_1exp",
  //     label: "Remarks #2",
  //     placeholder: "Remarks",
  //     type: "text",
  //   },
  // ];




//   modal

const Modalfields = [
    { name: "Bank Name", label: "Bank Name", type: "text" },
    {
      name: "Type",
      label: "Type",
      type: "dropdown",
      options: [
        {
          value: "Bank",
          label: "cash",
        },
        {
          value: "PettyCash",
          label: "Petty Cash",
        },
        {
          value: "Credit",
          label: "Credit",
        },
      ],
    },
    { name: "Currency", label: "Currency", type: "text" },
  ];
