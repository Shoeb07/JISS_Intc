import React, { useEffect, useState } from "react";
import "./DgExpensesScreen.css";
import {
  MdAddCircleOutline,
  MdOutlineKeyboardBackspace,
  MdOutlineNavigateNext,
} from "react-icons/md";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import Del from "../../../Components/Buttons/Del";
import { toast } from "react-toastify";
import { IoIosArrowBack, IoIosArrowForward } from "react-icons/io";
import { FaHome } from "react-icons/fa";
import { GrFormNext, GrFormNextLink, GrNext } from "react-icons/gr";
// import.meta.env;

const DgExpensesScreen = () => {
  // const URL = process.env.REACT_APP_1SD_API_URL;
  const URL = import.meta.env.VITE_REACT_APP_1SD_API_URL;

  const [expData, setExpData] = useState();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const response = await axios.get(
          // `${URL}/api/getAllExpenses`
          "https://api.1sdapp.com/api/getAllExpenses"
          // "https://home1.1sdapp.com/api/getAllExpenses"
          // "https://api.1sdapp.com/api/getAllExpenses"
        );
        console.log(response?.data.data, "getAllExpenses");
        setExpData(response?.data.data);
      } catch (err) {
        console.log(err);
      }
    };
    fetchData();
  }, []);

  const handleClick = async (id) => {
    try {
      // const response = await axios.delete(`${URL}/api/deleteExpense/${id}`

      const response = await axios.delete(`${URL}/api/deleteExpensesDetails`, {
        data: { exp_id: id },
      });

      const updatedList = expData.filter((item) => item.id !== id);
      setExpData(updatedList);
      toast.success(response.data.message);
    } catch (err) {
      console.log(err, "errorr");
      toast.error("Operation Failed");
    }

    console.log(id, "Del Clicked");
  };

  const Navigate = useNavigate();
  return (
    <div className="DgExpenses-main">
      {/* <span
        onClick={() => Navigate(-1)}
        className="mr-10 items-center text-[0.9rem] w-fit h-fit flex px-3 gap-2 py-0 rounded-sm cursor-pointer border-2 border-[#004aad] hover:bg-[#004aad] hover:text-white "
      >
        <MdOutlineKeyboardBackspace className="font-bold text-xl" />
        back
      </span> */}

      <div className="title text-white p-4 text-3xl font-bold border-b-2 bg-[#004aad] shadow-xl flex justify-between items-center mb-[30px]">
        <div className="flex-1 flex items-center">
          <span className="cursor-pointer" onClick={() => Navigate("/")}>
            1SD
          </span>
        </div>
        <div
          // onClick={() => Navigate(-1)}
          className="flex-1 text-center cursor-pointer uppercase  text-2xl"
        >
          {/* Company Registration */}
        </div>
        <div className="flex-1 flex justify-end items-center  gap-5">
          <span
            onClick={() => Navigate(-1)}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            {/* <MdOutlineKeyboardBackspace className="font-bold text-xl" /> */}
            {/* <IoCaretBackOutline className="font-bold text-xl" /> */}
            <IoIosArrowBack className="font-bold" />
            Back
          </span>
          <span
            onClick={() => Navigate("/dglory/expenses")}
            className="items-center text-[0.9rem] flex px-3 py-0 rounded-sm cursor-pointer border-2 hover:bg-white hover:text-[#004aad] self-end"
          >
            Next
            <IoIosArrowForward className="font-bold" />
          </span>
          <div
            onClick={() => Navigate("/")}
            className="p-1 border-[0.1rem] border-white hover:text-[#004aad] cursor-pointer hover:bg-white flex flex-col items-center rounded-md"
          >
            <FaHome className=" text-[1.2rem] " />
            <span className=" text-[0.6rem] leading-3">Home</span>
          </div>
        </div>
      </div>

      <div className="cards" onClick={() => Navigate("/dglory/expenses")}>
        <div className="outer flex gap-2 items-center">
          <h2 className="text-xl uppercase font-semibold text-white">
            Add Expenses{" "}
          </h2>
          <MdAddCircleOutline className="text-xl text-white" />
        </div>
      </div>
      <div className="p-8 w-full h-full">
        <div className="existingCompanies">
          <h2 className="text-xl text-center p-3 uppercase tracking-wider">
            Expenses
          </h2>
          {expData?.map((values, id) => (
            <div key={id?.id} className="eDetails">
              <p>
                {" "}
                <span className="font-bold text-black">Project / PO:</span>{" "}
                {values?.Project_Po}{" "}
              </p>
              <p>
                {" "}
                <span className="font-bold text-black"> Client Name: </span>
                {values?.Business_name}{" "}
              </p>
              <p>
                {" "}
                <span className="font-bold text-black">
                  {" "}
                  Vendor Name:{" "}
                </span>{" "}
                {values?.Vendor_name}{" "}
              </p>
              <p>
                {" "}
                <span className="font-bold text-black">
                  {" "}
                  Total Amount with VAT:{" "}
                </span>{" "}
                {values?.total_with_VAT}{" "}
              </p>
              {/* <button>Edit</button>
            <Del handleClick={handleClick} id={values.id} /> */}
              {/* <button onClick={()=>handleClick(values)} >Deleteee</button> */}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default DgExpensesScreen;
