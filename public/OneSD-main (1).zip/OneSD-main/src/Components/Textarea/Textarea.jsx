import React from "react";

const Textarea = ({ name, value, label, onChange }) => {

  
  return (
    <div className="flex flex-col">
      <label className="text-white" htmlFor={name}>
        {" "}
        {label}{" "}
      </label>
      <textarea
        className="outline-none border-2 border-black rounded-sm p-2"
        rows={4}
        style={{ resize: "none" }}
        draggable={false}
        name={name}
        value={value}
        onChange={onChange}
        ></textarea>
        {/* {console.log(name, value, label, onChange, 'textArea')} */}
    </div>
  );
};

export default Textarea;
